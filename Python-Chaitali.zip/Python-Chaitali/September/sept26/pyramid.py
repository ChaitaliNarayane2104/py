# num=int(input("enter the numbe"))
# for i in range(1,num+1):
#     for k in range(i,2*i):
#         print("*",end="\t")
#     print()

# num=int(input("enter the number"))
# i=1
# while(i<=num):
#     j=1
#     while(j<=i):
#         print("*",end="\t")
#         j=j+1
#     print()
#     i=i+1

i=1
while(i<=num):
    j=1
    while(j<=i):
        print("                                                                                                                                                                                                                                                                                                                                                                                                                                                                         ")