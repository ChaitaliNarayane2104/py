for i in range(1,11):
    for j in range(1,11):
        print(j*i,end="\t")# \t will create table or divide it by lines vertically (inshort  give do tab)
    print()