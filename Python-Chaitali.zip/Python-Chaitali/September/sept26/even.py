n=int(input("enter the number"))
i=1
while i<=n:
    if i%2==0:
        print("even number are:{}" .format(i))
    i  = i+ 1