# prime number onli divide by 1 nd itself num (5/1,5/5)
for num in range(2,51):
    isprime=True
    for i in range  (2,num):
        if num%i==0:# here i value increase by1 nd check that  num divide by i
            # if num is not divide by i then it is prime num, if yes then it will break nd out
            #5%2,5%3,5%4,5%4 (only upto4 coz limit is num nd it is excluded only upto n-1  valie give
            isprime=False
            break
    if isprime:
        print (num)