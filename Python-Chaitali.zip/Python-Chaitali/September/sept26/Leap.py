year=(int(input("enter the year")))
if year%4==0:
    if year %100 == 0:
        if year % 400==0:
            print(f"{year} is leap year")
    print("year is leap year")
else:
    print("year is not leap year")