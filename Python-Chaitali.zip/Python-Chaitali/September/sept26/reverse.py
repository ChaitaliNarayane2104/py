str=str(input("enter the string"))
