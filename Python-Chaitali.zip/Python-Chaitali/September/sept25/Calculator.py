num1=int(input(" enter the 1st value"))
num2=int(input(" enter the 2nd value"))
operator=input("enter the operator")
if operator == "+":
    print(num1+num2)
elif operator =="-":
    print(num1-num2)
elif operator == "*":
    print(num1*num2)
elif operator == "/":
    print(num1//num2)

else:
    print("invalid")




