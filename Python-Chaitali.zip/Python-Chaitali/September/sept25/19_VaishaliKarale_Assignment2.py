# Assignment 1: Objective: Create a program that converts inches to feet, meters and centimeters and continue until the user wishes to
# Input:
# Prompt the user to enter a value (float) and the unit of measurement (e.g. inches).
# Prompt the user to select the target unit for conversion
# Prompt the user to press ‘Yes’ or ‘No’ to repeat
# Calculation:
# Convert the input value to the target unit using appropriate conversion factors.
# Use typecasting where necessary to handle different types of input.
# Use a while loop to repeat
# Use break statement to stop calculations one user enters ‘No’
# Output:
# Display the converted value along with its unit.
# Continue until the user presses No.
# Conversion Options:
# Inches to feet, meters, and centimeters.

while True:

    inch = float(input("Enter the value in inches: "))


    unit = input("Enter the target unit (feet, meters, centimeters): ").strip().lower()


    if unit == 'feet':
        converted_value = inch / 12
    elif unit == 'meters':
        converted_value = inch* 0.0254
    elif unit == 'centimeters':
        converted_value = inch * 2.54
    else:
        print("Invalid target unit. Please try again.")
        continue


    print(f"{inch} inches is equal to {converted_value:.2f} {unit}.")


    repeat = input("Do you want to convert another value? (Yes/No): ").strip().lower()
    if repeat != 'yes':
        break

print()
# -------------------------------------------
# Assignment 2: Build a calculator for +, -, * and / operations using if and else condition statements

num1=int(input(" enter the 1st value"))
num2=int(input(" enter the 2nd value"))
operator=input("enter the operator")
if operator == "+":
    print(num1+num2)
elif operator =="-":
    print(num1-num2)
elif operator == "*":
    print(num1*num2)
elif operator == "/":
    print(num1//num2)

else:
    print("invalid")

print()
# -------------------------------------------
# Assignment 3: Print a Fibonacci series of numbers starting from 2 go until 100

a, b = 0, 1
print("Fibonacci series starting from 2:")
while b <= 100:
    if b >= 2:
        print(b, end=" ")
    a, b = b, a + b
print()





