r=int(input("enter the radius"))
pi=3.14
area=pi*r*r
print ( "The area of Circle is : {}" .format(area))