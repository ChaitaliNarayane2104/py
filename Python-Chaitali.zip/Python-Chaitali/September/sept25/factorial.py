num= int(input("enter the nnumber"))
i=1
fact=1
while(num>1):
    fact=fact*num
    num=num-1
print(fact)