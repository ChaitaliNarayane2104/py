num=int(input("enter the number"))
i=1
sum=0
while(i<=num):
    sum=sum+num
    num=num-i
print(sum)
