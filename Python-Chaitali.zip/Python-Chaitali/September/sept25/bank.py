ch="y"
balance=int(input("enter the account balance"))
# choice which take from user is equal to y then this will go in loop
while ch=="y":

    withdraw=int(input("enter the withdraw amount"))
    if withdraw > balance:
        print(" error")

    else:
        print(" your current balance is : {}".format(balance-withdraw))
    ## to get choice we take input from user "y"
    ch=input("Do you want to continue[y/n]")


