# num1=int(input(" enter the 1st value"))
# num2=int(input(" enter the 2nd value"))
# operator=input("enter the operator")
# if operator == "+":
#     ### after string . formate is applicable
#     ### after .formate type num1 + num2 then it will run
#     print("Addition of {} and {} is :" .format(num1,num2),num1+num2)
# elif operator =="-":
#     print("Substrtion of {} and {} : " .format(num1,num2),num1-num2)
# elif operator == "*":
#     print("Multiplication of {} and {} : " .format(num1,num2),num1*num2)
# elif operator == "/":
#     print(print("Division of {} and {} : " .format(num1,num2),num1//num2))
#
# else:
#     print("invalid")
#



name= input("enter the name")
city=input("enter the city")
print()