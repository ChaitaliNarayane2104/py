ch1="y"
while ch1=="y":
    num1=int(input("enter the first number"))
    num2=int(input("enter the second number"))
    ch="y"
    while(ch=="y"):
        op=input("enter the operation")

        if  op =="+":
            print("Addition of {} and {} is:" .format(num1,num2),num1+num2)
        elif op == "-":
            print("Substraction of {} and {} is:".format(num1, num2), num1 - num2)
        elif  op =="*":
            print("Multiplication of {} and {} is:" .format(num1,num2),num1*num2)
        elif  op =="/":
            print("Division of {} and {} is:" .format(num1,num2),num1/num2)
        else:
            print("invaid input")
        ch = input("Do you want to perform another operation [y/n]")
    ch1= input("Do you want to chaneg number [y/n]")