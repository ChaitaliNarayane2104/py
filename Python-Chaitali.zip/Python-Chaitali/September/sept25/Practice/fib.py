n1 = 1
n2 = 2
print(n1)
print(n2)
for i in range(101):
    n3 = n1 + n2
    print(n3)
    n1, n2 = n2, n3
