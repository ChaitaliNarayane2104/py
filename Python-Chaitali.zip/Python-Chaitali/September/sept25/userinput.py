from logging import getHandlerNames

fname=input("enter the name")
lname=input("enter the name")
print("hi my name is : {} my last name is: {}".format(fname,lname))
print("hi my name is {name1} I am  {name2} ")