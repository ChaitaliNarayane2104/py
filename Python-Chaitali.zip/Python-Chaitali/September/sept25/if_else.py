number=12
if number % 2 == 0:
    print(" number is even")
else:
    print("number is odd")