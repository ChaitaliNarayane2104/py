num1=float(input("enter the monthly income"))
num2=float(input("enter the monthly expnses"))
saving=num1-num2
per_saving=(saving/num1)*100 #### this percentage give in decimal 45.34555555555
### to give decimal in 2 pt use {x:.2f}
per_expens=(num2/num1)*100
print("total income is: {} and total expenses are : {}" .format(num1,num2))
### in {} give only {:.2f} this give 2 decimal value nd apply %  to them
print("percentage of saving : {:.2f}% and percentage of expenses is :  {:.2f}%" .format(per_saving,per_expens))
