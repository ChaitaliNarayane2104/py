'''
i=2
while i<=10:
    print(i)
    i=i+1
'''
i=1
while True:
    print(i)
    i+=1