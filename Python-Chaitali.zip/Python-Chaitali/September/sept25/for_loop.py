# print("looping  using range (1,10)")
# for num in range(1,10):
#     print(num)


####......................................................................###
# num=int(input("enter the number"))
# for i in range(1,11):
#     print(num*i)


###............................................................###
# num=int(input("enter the number"))
# fac = 1
# for i in range(1,num+1):
#
#     fac=fac*num
#
# print(fac)
#

string1=input("enter the number")
for i in range(1,string1):




