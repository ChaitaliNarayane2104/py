while True:
    year=(int(input("enter the year")))
    if year%4==0:
        print("year is leap year")
    else:
        print("year is not leap year")
    choice=input("do you want to continue")
    if choice != 'y':
            print(" thank you for service")
            break