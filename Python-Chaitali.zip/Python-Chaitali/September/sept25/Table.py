'''
i=2
while i<=10:
    print(i)
    i=i+1
'''

'''
i=1
while i<=10:
    print(2*i)
    i=i+1
'''

'''
num= int(input("enter the nnumber"))
i=1
fact=1
while(num>1):
    fact=fact*num
    num=num-1
print(fact)

'''
'''
num=int(input("enter the number"))
i=1
sum=0
while(i<=num):
    sum=sum+num
    num=num-1
print(sum)
'''
num=int(input("enter the number"))
i=1
sum=0
while(i<=num):
    sum=sum+num
    num=num-1
print(sum)
