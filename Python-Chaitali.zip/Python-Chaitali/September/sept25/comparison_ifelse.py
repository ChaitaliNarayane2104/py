num1=int(input("enter the 1st value"))
num2=int(input("enter the 2nd value"))
print(" 1st value is : {} and 2nd value is : {}  " . format(num1,num2))
if num1 > num2:
    print("num1 is greater than num2")
else:
    print(" num2 is greater than num1")