# str1="Neha"
# for strChar in str1:
#     print(strChar)
#

# num=int(input("enter the number"))
# i=1
# sum=0
# while(i<=num):
#     sum=sum+num
#     num=num-i
# print(sum)

str1=str(input("enter the string"))
total=0
for char in str1:
    total=int(char)+total
print(total)


