# sum of digit suppose 1020 add(1+0+2+0)
num=int(input("enter the name"))
sum=0
while(num>0):
    ## every time divid each no. give reminder that reminder is last digit of number
    rem=num%10 ### after dividing 123 by 10 it will give reminder 3
    sum=sum+rem ### reminder will add
    num=num//10 ### after dividing 10 by n0 it will give int digit
    ## 123//10=12 now 12 will divid by 10 nd give reminder 2 same again
    # 12//10=1 give remider 1 nd add(1+2+3)
print(sum)
