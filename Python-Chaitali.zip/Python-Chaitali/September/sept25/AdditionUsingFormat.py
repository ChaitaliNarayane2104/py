num1=int(input("enter the 1st number"))
num2=int(input("enter the 2nd number"))
add=num1+num2
print("first number is : {} or 2nd number is : {} and addition is :{} " .format(num1,num2,add))
print(type(num1))
print(type(num2))