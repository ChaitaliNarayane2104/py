# for num in range(1,10):
#     if num == 5:
#         break #### this will break the loop from 5
#     print(num)
#..................................................................................................




# for num in range(1,10):
#     if num  == 5:
#         continue ### this will skip 5 nd then continue coz numm==5 so  condition is match or true
#     print(num)
#............................................................................................



# for num in range(1,10):
#     if num == 5:
#         break #### this will break the loop from 5
#     if num  == 3:
#         continue ### this will skip 5 nd then continue coz numm==5 so  condition is match or true
#     print(num)


#...............................................................................................

# number =0
# while number <10:
#     number+= 1
#     if number % 2 == 0:
#
#         continue
#     if number == 7:
#         print(" number 7 encounter")
#         break
#     print(f"current number {number}")



#.................................................................................................

# num=int(input("enter the number"))
# for i in range(1,11):
#     if i == num:
#         break
#     print(f"numbr is  {i}")


#..................................................................................................




#
# age=int(input("enter the age"))
# if age<5:
#     print("Free")
# elif age>5 & age<=10:
#     print("Rs.5")
# elif age>13 & age<=60:
#     print("Rs.13")
# elif(age>60):
#     print("Rs.7")
# else:
#     print("invalid age you enter")
#

#.....................................................................................................













