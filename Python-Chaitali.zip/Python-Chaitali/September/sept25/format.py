str1=input("enter the city name")
str2=input("enter the country name")
print("my city name is : {} and my country name is: {}".format(str1, str2))
print("my city name is : {city} and my country name is: {country}".format (city=str1,country=str2))
