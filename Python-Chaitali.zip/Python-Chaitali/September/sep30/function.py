def addNumber(num1,num2):
    result =num1 +num2
    #print(result)
    return result
num1=int(input("enter number1 :"))
num2=int(input("enter number2: "))
res = addNumber(num1,num2)
print(res)