# num=(1,2,3)
# num1=("a","c","d")
# num2=(5,)
# print(num)
# print(num1)
# print(num2)
# print(type(num))
# print(type(num1))
# print(type(num2))
# #
# print(num[0],num[-1]) # give 1st and last digit
#
# print("*****************************************************************")
#
# tuple=(1,2,3)
# a,b,c=(1,2,3) # in a,b,c this value 1,2,3 will strore
# print(a)
# print(b)
# print(c)
#
# print("*****************************************************************")
#
# t1=(1,2,3,4)
# t2=(3,4,5,6)
# combined=t1+t2 # this so will add tuple
# print(combined)
#
# print("*****************************************************************")
#
# length=len(t1)
# print(length)
# print("*****************************************************************")
#
# is_present= 2 in t1
# print(is_present)
# is_present1= 8 in t1
# print(is_present1)
#
# print("*****************************************************************")
#
# count=t1.count(2) # count give position
# print(count)
#
# print("*****************************************************************")
#
# t1 = (1,2,3,4)
# repeated=t1*3 # repate this list 3times
# print(repeated)
# mylist1=sorted(repeated) # sorted this list nd give list
# print(mylist1)
# sorted_tuple= tuple(mylist1) # tuple() this convert list to tuple
# print(sorted_tuple)
#
# print("*****************************************************************")
#
# my_list=list(sorted_tuple) #list() convert tuple to list
# print(my_list)
#
# my_tuple = (1,2,3)
# my_tuple[0] = 10  # this give error coz tuple are immutable this not store new value
#




















