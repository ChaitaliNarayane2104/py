# mylist =[]
# while True:
#     num=int(input("enter the list"))
#     mylist.append(num)
#     ch= str(input("do you want to add y/n "))
#     if ch != "y":
#         break
# print(mylist)
# convert = tuple(mylist)
# print(convert)
# print("1st element of tuple:",convert[0])
# print("last element of tuple" ,convert[len(convert) -1])
# print("1st & last element" ,convert[0],convert[len(convert) -1])
# print(" 1st & last element eith stepm2 : " ,convert[0],convert[len(convert) -1],2)
# print("reverse" ,convert[::-1])


#
# name=(input("enter the name"))
# age=(input("eneter the age")
# my_tuple =(name ,age)  this will store value in tuple = (name,age) just by using () it will convert in tuple
# print(my_tuple)
# new_name,new_age=my_tuple
# print(new_name)
# print(new_age)


number=(input("enter the number"))
my_tuple=tuple(number)
print(my_tuple)
#tuple_string =''.join(map(str, my_tuple))
#tuple_int=int(tuple_string)
#print(tuple_string)
# sum=0
# for i in my_tuple:
#     sum=sum+int(i)
# print(sum)

