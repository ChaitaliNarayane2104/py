str1="1"
print(type(str1))

iNum1=int(str1)
print(iNum1)
print(type(iNum1))
4