a=2
b=2.5
c="neha chaitali"
d=True
print(a,b,c,d)