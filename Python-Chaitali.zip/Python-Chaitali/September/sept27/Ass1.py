ch="y"
while ch=="y":
    num=int(input("enter the how many you want to print : "))
    for i in range(1,num+1):
        print("*",end="\t")
    print()
    ch=(input("Do ypu want to continue??[y/n]"))