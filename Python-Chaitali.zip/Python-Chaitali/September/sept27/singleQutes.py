singal_quotes ='ho'
double_quotes ="hi"
triple_quotes ='''hi'''

print(type(singal_quotes))
print(type(double_quotes))
print(type(triple_quotes))

escape_seq ='hi\'good\'!\t have agood day \n day!!' ### \t means tab give space
print(escape_seq)
escape_seq1 ='hi\'good\'!\n have agood day \n day!!'  ## print in new line
print(escape_seq1)
