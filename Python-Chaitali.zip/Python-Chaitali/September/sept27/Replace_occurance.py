# text="Chaitali"
# #sub="tali"
# print(text.find("tali"))
#
# print(text.replace("tali","nah"))

text="Neha"
print(text.replace("h","C",2))  # 1 replace the 1st  charceter

print(text.replace("h","C"))  # 1 replace the 1st  charceter