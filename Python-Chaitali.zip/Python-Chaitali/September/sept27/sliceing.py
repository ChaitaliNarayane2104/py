result ="Chaitali"
print(result)

# sub=result[0:4]
# print(sub)
#
# sub=result[:4]
# print(sub)

sub=result[::-1] #reverse the string
print(sub)

sub=result[4:]
print(sub)

sub=result[1:3]
print(sub)