# str1=" neha santosh sawant          "
# str2=str1.strip()
# print(str2)
# print(len(str2))
 #####################################

# str1=str(input(" enter  name"))
# str2=str(input("enter  surname"))
# print(str1  + " "+ str2)

#
# ch="y"
# while ch=="y":
#     str1=input("enter the string")
#     str2=input("enter the second string")
#     comp=str1==str2
#     print(comp)
#     ch=input("Do you want continue[y/n]")



while True:
    str1=input("enter the string")
    str2=input("enter the second string")
    comp=str1==str2
    print(comp)
    choice=input("do you want to continue y/n")
    if choice != "y":
        print("thank")
    break

