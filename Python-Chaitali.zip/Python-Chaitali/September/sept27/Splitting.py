# resCon="abcd"+"efghi"
# print(resCon)

# print(type(resCon))
# resSplit=resCon.split(",")
# print(type(resSplit))
# print(resSplit)


sen="Chaitali-Narayane"
new=sen.split("-") #it will split from -
print(new)