# text="ChaitaliNarayane"
# print(text[2:3])
# print(text[3:8])
# print(text[1:15]) # direct give position[6:7] it will remove character
# print(text[1:-1]) #It will remove the 1st and last charcter of the string
name=input("enter the string in lower case")
print(name.upper())
