
print("++++++++++++++++++++++ADDITION  OF STRING++++++++++++++++++++++++++++++")

str1="quick brown"
str2=" neha"

result= str1 + str2      # add string
print(result)

rep = result * 3      # repetation of string
print(rep)

length=len(result) # print length
print(length)

print("++++++++++++++++++++++STRIP++++++++++++++++++++++++++++++")

str1 ="abcd" + " "
print(str1)
print(len(str1))

str1_strip= str1.strip()  # .strip remove/doesn't count  the spaces forward and backward
print(len(str1_strip))

print("******************************* FIND/REPLACE**********************************************")

print(result)
pos=result.find("neha") #print the index number where "neha" word found
new_string=result.replace("neha","chaitali")
print(pos)
print(new_string)



#STRING MEMBERSHIP
print("+++++++++++++++++STRING MEMBERSHIP++++++++++++++++++++")

result="asghasgd"
member = "asg" in result  #It will check given charcter is present or not , if present then it print "True else print False
print(member)


print("++++++++++++++++++++++STRING COMPARISON++++++++++++++++++++++++++++++")

str1="neha"
str2="Chaitali"
comp=str1==str2
print(comp)

