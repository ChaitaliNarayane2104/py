i=1
while True:
    print(i)
    i+=1
else:
    print("m")