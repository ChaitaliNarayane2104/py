ch="y"
data=[]
while ch=='y':
    print(["Add,Remove,View"])
    userinput=input(" whcih task wantto perform:")

    if userinput=="add" :
        data1=input("enter the data:")
        data.append(data1)
        print(data)
        ch=input("Do yo want to peform another y/n:")
    elif userinput == "view":
        print("your data is")
        print(data)
        ch = input("Do yo want to peform another y/n:")
    elif userinput == "remove":
        r=input("what do you want to remove")
        data.remove(r)
        print(data)
        ch = input("Do yo want to peform another [y/n]:")


# ch="y"
# while ch=="y":
#
#     task=str(input("enter the task"))
#     task1.append(task)
#     print(task1)
#
#     ch=input("Doo you want to add any task[y/n]")
