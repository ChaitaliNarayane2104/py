# ch=int(input("how many numbers you want to enter:"))
# for i in range(ch):
#     number=input("enter the number")
# print(number[i])
for num in range(2,51):
    isprime=True
    for i in range  (2,num):
        if num%i==0: isprime=False
            break
    if isprime:
        print (num)