mylist=[12,34,22,12,True,"String"]
#clearing list
print(mylist)
mylist.clear()
print(mylist)