#List-It can hold any type of data
#List is mutable
#Allow duplicate data
#maintain order of insertion means whatever you put first it always place in 1st and like wise

mylist=[1,2,3,4,5,6,7,8]
print(mylist)
print()

mixed_list=[1,"hello",3.24,True]
print(mixed_list)
print()

print("empty list")
emptylist=[]   #it willl print empty llist
print(emptylist)
print()

print("print number at given index")
mylist[0]=10 #it will print 10 at index 0
print(mylist)
print()

print("append")
mylist.append(6) #it will append(means add) 6 to last
print(mylist)
print()

print("insert")
mylist.insert(1,15) #insert 15 at index 1
print(mylist)
print()

print("extend")
mylist.extend(["string",8,True])  #it will extend string means add these element in list
print(mylist)

print()

print("delete")
del mylist[0] #it will delete element which is present at index of 0
print(mylist)
print()

print("pop")
mylist.pop(1) #remove and return the element at index 1
print(mylist)
print()

print("Remove")
mylist.remove(6) #it remove 1st occurance of 6
print(mylist)
print()


print("finding index of element")
print(mylist)
print(mylist.index(7))

print()

print("Count")
print(mylist.count(True)) #it will count the how many time True occur

print()

print("sort")
name=[2,4,6,1,9]
name.sort()
print(name)
print(type(name))

print("sorted")

my_list_sorted=sorted(mylist)
print(my_list_sorted)
print(mylist)

print("Reverse")
mylist.reverse()
print(mylist)


print()
print("copy") #it will copy list
mylistcopy=mylist.copy()
print(mylistcopy)
print()

print("Joining list")
l1=[1,2,3]
l2=[4,5]
combo=l1+l2
print(combo)

print()