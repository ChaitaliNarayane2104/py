name1=input("Enter the 1st string")
name2=input("enter the secnd string")
sort1=sorted(name1)
sort2=sorted(name2)
if sort1==sort2:
    print("Anagram")
else:
    print("not Anagram")
