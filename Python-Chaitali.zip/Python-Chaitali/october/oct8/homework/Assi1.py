def fahrenheit_to_celsius(f):
    try:
        f = float(f)  # Convert input to float
        c = (f - 32) * 5.0/9.0  # Convert Fahrenheit to Celsius
        return c
    except ValueError:
        return "Invalid input! Please enter a numeric value."

def celsius_to_fahrenheit(c):
    try:
        c = float(c)  # Convert input to float
        f = (c * 9.0/5.0) + 32  # Convert Celsius to Fahrenheit
        return f
    except ValueError:
        return "Invalid input! Please enter a numeric value."

# Example usage
fahrenheit_input = input("Enter temperature in Fahrenheit: ")
celsius_input = input("Enter temperature in Celsius: ")

print(f"Fahrenheit to Celsius: {fahrenheit_to_celsius(fahrenheit_input)}")
print(f"Celsius to Fahrenheit: {celsius_to_fahrenheit(celsius_input)}")

