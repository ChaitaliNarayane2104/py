# try:
#     x=int(input("no number")) #this raise valueerror
# except ValueError:
#     print(":caught a vlaueerror:invalide literal for int()")
# print("\n")
# print("Demo1: base try except block")
# try:
#     x=int(input("5")) #this raise valueerror
# except ValueError:
#     print(":caught a vlaueerror:invalide literal for int()")

def get_integer_input(num):

        num=int(input("enter number"))
        return num
try:
    get_integer_input(int)
except ValueError:
    print("caught a valueerror ")



