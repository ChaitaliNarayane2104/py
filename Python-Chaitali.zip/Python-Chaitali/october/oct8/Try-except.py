#try-except block
# print("Demo1: base try except block")
# try:
#     x=int(input("no number")) #this raise valueerror
# except ValueError:
#     print(":caught a vlaueerror:invalide literal for int()")
# print("\n")
# print("Demo1: base try except block")
# try:
#     x=int(input("5")) #this raise valueerror
# except ValueError:
#     print(":caught a vlaueerror:invalide literal for int()")
# print("\n")


# print("Demo2 Mulitple except except block")
# try:
#     y=10/0 #this will raise zerodivisionerror
# except ValueError:
#     print("Caught valueError")
# except ZeroDivisionError:
#     print("Caught ZeroDivisionError: division by zero is not allowed")

# print("Demo3 Finally block")
# try:
#     y=10/0 #this will raise zerodivisionerror
# except ValueError:
#     print("Caught valueError")
# except ZeroDivisionError:
#     print("Caught ZeroDivisionError: division by zero is not allowed")
# finally:
#     print("this will always execute, regardless of whether an exception occure")#always runs

# print("Demo4 Try exceptblock")
# try:
#     y=10/0 #this will raise zerodivisionerror
# except ValueError:
#     print("Caught valueError")
# except ZeroDivisionError:
#     print("Caught ZeroDivisionError: division by zero is not allowed")
# else:
#     print("hello")
# finally:
#     print("this will always execute, regardless of whether an exception occure")#always runs

print("Demo2 Mulitple except except block")
try:
   age= -1
   amount=-1000
   if age<0:
       raise ValueError("age cannot negative")#raise valueerror manually
   if amount<0:
       raise ValueError("Amount cannot be negtaive")#raise value error anually
except ValueError as e:
    print(f"raise and caught exception:{e}")
