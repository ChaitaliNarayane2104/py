import csv

mylist=['c','e','a','d','b']
def write_list(filename,data:mylist):
        data.sort()
        with open(filename,'w') as file:
            for i in data:
                file.write(i)

            print(mylist)
        print(f"data write successfully{filename}")
#filename='file.csv'
filename=r'C:\Users\dhpcsa\Desktop\FCNM\gun.csv'
write_list(filename,mylist)


def read_list(filename,data:mylist):
        with open(filename,'r') as file:
            print(f"data read successfully{filename}")
#filename='file.csv'
filename=r'C:\Users\dhpcsa\Desktop\FCNM\gun.csv'
read_list(filename,mylist)
