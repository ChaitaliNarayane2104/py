mylist=[21,12,3,4,3,2]

def write_list(filename:str,data:mylist):
    with open(filename,'w') as file :
        for i in data:
            file.write(str(i))
            file.write(f"\n")
        print(f"data write successfully{filename}")

filename='numbers.txt'
write_list(filename,mylist)


new_list=[]
def read_list (filename:str,data:mylist):
    with open(filename,'r') as file:
        for i in data:
            file.read(i)
            new_list.append(i)
            #file.read(f"\n")
    print(f"data read successfully{filename}")
    print(new_list)
filename='numbers.txt'
read_list(filename,mylist)

#
# def write_to_file(filename: str, data:dict):
#     with open(filename, 'a') as file:
#         for key,value in data.items():
#             file.write(f"{key}: {value} ")
#         file.write(f"\n")
#         #file.write(data)
#     print(f"data writtemn to {filename} successfully")
#
#
# filename = 'example2.txt'
# write_to_file(filename,dict)