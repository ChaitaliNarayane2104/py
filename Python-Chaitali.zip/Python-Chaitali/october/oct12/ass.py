# import re
#
# phrase = "quick brown fox jumps over a lazy dog"
# # Split the phrase into a list
# words_list = re.findall(r'\S+', phrase)  # \S+ matches sequences of non-whitespace characters
# # Replace 'fox' with 'lion'
# words_list = [re.sub(r'fox', 'lion', word) for word in words_list]
# print(words_list)
#


# def find_start_with_lowercase(strings):
#     return [s for s in strings if s and s[0].islower()]
#
#
# strings = ["apple", "Banana", "cherry", "date", "Elderberry"]
# result = find_start_with_lowercase(strings)
# print(result)

# import re
#
# def find_lowercase_substrings(strings):
#     return [s for s in strings if re.fullmatch(r'[a-z]+', s)]
#
#
# strings = ["chaitali", "neha", "vaishali", "123", "mitali"]
# result = find_lowercase_substrings(strings)
# print(result)

import re

#
# def find_exact_repetitions(strings, pattern, n):
#     result = []
#     regex = re.compile(f"({pattern}){{{n}}}")
#
#     for string in strings:
#         if regex.search(string):
#             result.append(string)
#
#     return result
#
# strings = ["hellooo", "hoooray", "aaaaaaa", "123456", "boooom"]
# pattern = 'o'
# n = 3
#
# output = find_exact_repetitions(strings, pattern, n)
# print(output)

# # Define a function to check the lines
# def process_lines(file_path):
#     with open(file_path, 'r') as file:
#         for line in file:
#             clean_line = line.strip()
#             if clean_line.startswith("Start") and clean_line.endswith("End"):
#                 print(clean_line)
#
# file_path = "/mnt/data/file-pZMgH8wxG6WMQ54UQp7o9yQE"
#
# process_lines(file_path)


import re
text = """
Apple pie is delicious. 
Under the bed, there is a cat! 
Notes from the meating! 
123456750908 to check the detalla!
"""
print(re.findall(r'\b([aeiou][^aeiou]+[bcdfghjklmnpqrstvwxyz])\b', text, flags=re.IGNORECASE))
print(re.findall(r'\d+(?=\D)', text))
print(re.findall(r'^Note.*!$', text, flags=re.MULTILINE))