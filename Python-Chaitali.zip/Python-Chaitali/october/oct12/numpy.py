# 0-dimension array(scalar)
# 1-dimension array (vector)
# 2-dimension array (matrix)
# 3-dimension array (tensor)

#
# import numpy as np
# array_1d=np.array([1,2,3,4,5])
# print("1D array:\n, array_1d")
#
# array_2d=np.array([1,2,3],[4,5])
# print("2D array:\n", array_2d)
# array_3d=np.array([1,2,3],[4,5],[3,4,5,67])
# print("3D array:\n", array_3d)
# zeros=np.zeros((2,3))
# print("array of ones:\n",zeros)
# ones=np.ones((2,6))
# print("array of ones:\n",ones)\
# fully_array=np.full((2,3),6)
# print("array of ones:\n",full_array)
# range_array=np.arange((2,3),6)
# print("array of ones:\n",range_array)
# step_array=np.step((2,3),6)
# print("array of ones:\n",step_array)
#
# import numpy as np
#
# # 1D array
# array_1d = np.array([1, 2, 3, 4, 5])
# print("1D array:\n", array_1d)
#
# # 2D array (list of lists)
# array_2d = np.array([[1, 2, 3], [4, 5, 6]])
# print("2D array:\n", array_2d)
#
# # 3D array (list of lists with consistent inner lists)
# array_3d = np.array([[[1, 2, 3], [4, 5, 6]], [[7, 8, 9], [10, 11, 12]]])
# print("3D array:\n", array_3d)
#
# # Array of zeros
# zeros = np.zeros((2, 3))
# print("Array of zeros:\n", zeros)
#
# # Array of ones
# ones = np.ones((2, 6))
# print("Array of ones:\n", ones)
#
# # Array filled with a specific value (6 in this case)
# full_array = np.full((2, 3), 6)
# print("Array filled with 6:\n", full_array)
#
# # Array with a range of values
# range_array = np.arange(2, 6)  # From 2 to 5
# print("Range array:\n", range_array)
#
# # Array with steps (np.arange with step)
# step_array = np.arange(2, 6, 1)  # From 2 to 5 with step of 1
# print("Step array:\n", step_array)


import numpy as np

# Assignment 1
array_1d = np.arange(20)
print("1D Array:")
print(array_1d)

# Assignment 2
array_2d = array_1d.reshape(4, 5)
print("\n2D Array:")
print(array_2d)

flattened_array = array_2d.flatten()
print("\nFlattened Array:")
print(flattened_array)

# Assignment 3
random_matrix = np.random.randint(1, 11, size=(3, 3))
print("\nRandom 3x3 Matrix:")
print(random_matrix)

transposed_matrix = random_matrix.T
print("\nTransposed Matrix:")
print(transposed_matrix)
