#Regular Expression
# .     match any charcter any charcter except new line
# ^     match the start of string
# $     match end of string
# *     match 0 or more repetitions of preceding element
# +     match 1 or more repetitions of preceding element
# ?     match 0 or 1 repetitions of preceding element
# {}    specified exact number of repetition
# []    match any one of charcter inside the char.
# |     match th either the expression before or after the operation

#re.search():   search for 1st match of patter
#re.match():    check of match only at begining of string
#re.findall():  find all non-overlapping match of the pattern of string
#re.sub():      substitute match with a string
#re.split():    split the string by occurance of the pattern