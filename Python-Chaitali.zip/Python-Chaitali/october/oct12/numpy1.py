
# import numpy as np
#
# # Assignment 1
# array_1d = np.arange(20)
# print("1D Array:")
# print(array_1d)
#
# # Assignment 2
# array_2d = array_1d.reshape(4, 5)
# print("\n2D Array:")
# print(array_2d)
#
# flattened_array = array_2d.flatten()
# print("\nFlattened Array:")
# print(flattened_array)
#
# # Assignment 3
# random_matrix = np.random.randint(1, 11, size=(3, 3))
# print("\nRandom 3x3 Matrix:")
# print(random_matrix)
#
# transposed_matrix = random_matrix.T
# print("\nTransposed Matrix:")
# print(transposed_matrix)



import numpy as np


array_1d = np.arrange(20)
print("1D Array:")
print(array_1d)


array_2d = array_1d.reshape(4, 5)
print("\n2D Array:")
print(array_2d)

flattened_array = array_2d.flatten()
print("\nFlattened Array:")
print(flattened_array)


random_matrix = np.random.randint(1, 11, size=(3, 3))
print("\nRandom 3x3 Matrix:")
print(random_matrix)

transposed_matrix = random_matrix.T
print("\nTransposed Matrix:")
print(transposed_matrix)

#assignment
def find_longest_word(word_list):
    return max(len(word) for word in word_list)

#
# Alternatively:
#
#
# def find_longest_word(word_list):
#     return len(max(word_list, key=len))
# #Assignment
#
# def overlapping(list1, list2):
#     return len(set(list1) & set(list2)) > 0
#
# # Alternatively
# def overlapping(list1, list2):
#     return any(item in list2 for item in list1)
# def find_longest_word(world_list):
#      return len (max(word_List,key=len))
# def overlapping(list1)