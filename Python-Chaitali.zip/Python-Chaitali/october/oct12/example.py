import re
#'.' metacharcter-match any charcter except a newline
#match any char.between a and b
r1=re.findall(r'a.b','aab acb a#b adb ab a\nb zab and ajb')
print(r1)
print()

r2=re.findall(r'^Hello', 'world! hello again1')
print(r2)
print()

r3=re.findall(r'end.$','this is end. this is the end.')
print(r3)

r4 =re.findall(r'ca*t', 'ct cat caat caaat cacacat')
print(r4)
print()

r5= re.findall(r'go+', 'go goo goooo gvfd tgoot')
print(r5)
print()

r6=re.findall(r'a{2,3}', 'a aa aaa aaaa aaaaaa') #specified exact number of repition
print(r6)
print()

r7=re.findall(r'[aeiou]','mumbai pune delhi')
print(r7)

# r8=re.findall()
# str1="the price is 100 dollor and 200 "

