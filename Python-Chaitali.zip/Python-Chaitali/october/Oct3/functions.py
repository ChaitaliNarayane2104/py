# def processnumber(num1,num2):
#     add=num1+num2
#     mul=num1*num2
#     return add,mul
# num1=int(input("enter the number1"))
# num2=int(input("enter the number2"))
# res=processnumber(num1,num2)
# print(res)
# print(type(res))
from itertools import count

# list=[]
# limit=int(input("how many number do you want to enter"))
# for i in range(limit):
#     num=int(input("enter the number"))
#     list.append(num)
# print(list)
# def sum(list):
#     sum=0
#     for i in list:
#         sum=sum+i
#     return sum
#
# print(sum(list))


# list=[]
# limit=int(input("how many number do you want to enter"))
# for i in range(limit):
#     num=int(input("enter the number"))
#     list.append(num)
# dict={}
# def countfreq(list):
#     for i in list:
#         x=list.count(i)
#         dict.update({i:x})
#     return dict
# print(countfreq(list))


#limit=int(input("how many number do you want to enter"))
#for i in range(limit):
number = input("enter the number without space")
my_tuple = tuple(number)
    #print(my_tuple)
print(my_tuple)
def sum_product(my_tuple):
    sum=0
    product=1
    for i in my_tuple:
        sum=sum+int(i)
        product=product*int(i)
    return sum,product

print(sum_product(my_tuple))