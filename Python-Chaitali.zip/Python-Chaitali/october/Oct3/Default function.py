# def processnumber(num1,num2=5):
#     add=num1+num2
#     mul=num1*num2
#     return add,mul
# num1=int(input("enter the number1"))
# num2=int(input("enter the number2"))
# res=processnumber(num1)
# print(res)
# print(type(res))

# def processnumber(num1,num2,num3):
#     add=num1+num2+num3
#     mul=num1*num2+num3
#     return add,mul
# num1=int(input("enter the number1"))
# num2=int(input("enter the number2"))
# num3=int(input("enter the number2"))
# res=processnumber(num1=3,num2=2,num3=1)
# print(res)
# print(type(res))


# def greet(name,msg="hello"):
#     print(f"{msg},{name}!")
# greet("alice")
# greet(name="alie",msg="gm") #
# greet(msg="hi",name="bob")
# greet("hi","alice")



