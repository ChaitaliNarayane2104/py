# shop={}
# store_dict={}
# item = input("enter the items")
# while True:
#     store_dict["Quantity[0"]=input("enter the quntity")
#     store_dict["price"]=input("enter the price")
#     shop.update({item:store_dict})
#     print(shop)
#     ch =input("do you want to update quantity nd price[y/n")
#     if ch != 'y':
#         shop.update({item: store_dict})
#         break

#
# list1=[]
# for i in range(4):
#     x=str(input("Enter the strings: "))
#     list1.append(x)

data={}
bigdata={}
print(["Add,Search,Update,Delete"])
contactname=input("enter the contactname")
while True:
    data["phonnumber"]=input("enter the phone number")
    data["email"]=input("enter the email")
    bigdata.update({contactname:data})
    print(bigdata)



