people={"neha":"purple","Chaitali":"blue","vaishali":"black","hite":"yellow"}

x=len(people)
print(x)
print()
y=people.update({"neha":"red"})
print()
print(people)
r=people.pop("vaishali")
print(people)

s=dict(sorted(people.items()))
print(s)