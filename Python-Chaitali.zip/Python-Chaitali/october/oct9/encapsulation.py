# class Book:
#     strLibrararyname="city libarbry"
#     def __init__(self,bookTitle,bookAuthor,available):
#         self.bookTitle=bookTitle
#         self.bookAuthor=bookAuthor
#         self.available=available
# mybook=Book("Wings_of_fire","Abdul kalam",True)
# mybook1=Book("chem","Chaitali",False)
# print(f"Libarary name:{Book.strLibrararyname}")
# print(f"book Title:{mybook.bookTitle}")
# print(f"Book author:{mybook.bookAuthor}")
# print(f"Available:{mybook.available}")
from September.sept28.Anagram import name1


class clsschool:
    school_name="Green_Valley_High_School"
    def __init__(self,name,student_id):
        self.name=name
        self.student_id=student_id
        self.mathmark=0
        self.sciencemark=0
        self.englishmark=0
    def add_marks(self,sub,marks):
        if sub=="math":
            self.mathmark=marks
        elif sub=="sci":
            self.sciencemark=marks
        elif sub=="eng":
            self.englishmark=marks
        else:
            print("invalid ")
    def cal_avg(self):
        totalmarks=self.mathmark+self.sciencemark+self.englishmark
        self.avg=totalmarks/3
    def display(self):
        print(f"student name:{self.name}" )
        print(f"student id:{self.student_id}")
        print(f"student math marks:{self.mathmark}")
        print(f"student sci marks:{self.sciencemark}")
        print(f"student eng marks:{self.englishmark}")
        print(f"student avg:{self.avg}")

