# class car:
#     wheels=4
#     def display(self):
#         print(f"my car has {self.wheels} wheels")
#
# my_car=car()
# my_car.display()
#
# class clsphonebook:
#     strname=""
#     strphone=""
#     straddress=""
#     def __init__(self,name,phone,add):
#         self.atrname=name
#         self.strphone=phone
#         self.straddress=add
#
#     def set_value(self,name,phone,add):
#         #attribute of the class
#         self.strname=name
#         self.strphone=phone
#         self.straddress=add
#
#     def display_phonebook(self):
#         print("name:",self.strname)
#         print("phone:",self.strphone)
#         print("address:",self.straddress)
#
# if __name__=="__main__":
#     #constructor
#     objphonebook1 = clsphonebook(name:"Neha",phone:"23456",add:"kothrud")
#     objphonebook2 = clsphonebook(name:"Chatali",phone:"54637827328"",add:"Nashik")
#     #objphonebook1.display_phonebook()
#     #objphonebook2.display_phonebook()
#
#
# listobjlist=[]
#
# listobjlist.append(objphonebook1)
# listobjlist.append(objphonebook2)
# for items in listobjlist:
#     items.display_phonebook()



#
# class clsphonebook:
#     def __init__(self, name, phone, add):
#         self.strname = name
#         self.strphone = phone
#         self.straddress = add
#
#     def set_value(self, name, phone, add):
#         self.strname = name
#         self.strphone = phone
#         self.straddress = add
#
#     def display_phonebook(self):
#         print("Name:", self.strname)
#         print("Phone:", self.strphone)
#         print("Address:", self.straddress)
#         print()  # Adding a new line for better readability
# print(__name__)
# if __name__ == "__main__":
#     # Creating instances of clsphonebook
#     objphonebook1 = clsphonebook(name:"neha",phone:"7654783",add:"pune")
#     objphonebook2 =clsphonebook(name:"neha",phone:"7654783",add:"pune")
#     # Adding objects to a list
#     listobjlist = []
#     listobjlist.append(objphonebook1)
#     listobjlist.append(objphonebook2)
#
#     # Displaying the phonebook entries
#
#     for item in listobjlist:
#         item.set_value("neha","7654783","pune")
#
#         item.display_phonebook()
#

class clsphonebook:
    def __init__(self, name, phone, add):
        self.strname = name
        self.strphone = phone
        self.straddress = add

    def set_value(self, name, phone, add):
        self.strname = name
        self.strphone = phone
        self.straddress = add

    def display_phonebook(self):
        print("Name:", self.strname)
        print("Phone:", self.strphone)
        print("Address:", self.straddress)
        print()  # Adding a new line for better readability

if __name__ == "__main__":
    # Creating instances of clsphonebook
    objphonebook1 = clsphonebook(name="Neha", phone="23456", add="Kothrud")
    objphonebook2 = clsphonebook(name="Chatali", phone="54637827328", add="Nashik")

    # Adding objects to a list
    listobjlist = []
    listobjlist.append(objphonebook1)
    listobjlist.append(objphonebook2)

    # Displaying the phonebook entries
    for item in listobjlist:
        item.display_phonebook()

