# class Book:
#     strLibrararyname="city libarbry"
#     def __init__(self,bookTitle,bookAuthor,available):
#         self.bookTitle=bookTitle
#         self.bookAuthor=bookAuthor
#         self.available=available
# mybook=Book("Wings_of_fire","Abdul kalam",True)
# mybook1=Book("chem","Chaitali",False)
# print(f"Libarary name:{Book.strLibrararyname}")
# print(f"book Title:{mybook.bookTitle}")
# print(f"Book author:{mybook.bookAuthor}")
# print(f"Available:{mybook.available}")

#
# class clsschool:
#     school_name="Green_Valley_High_School"
#     def __init__(self,name,student_id):
#         self.name=name
#         self.student_id=student_id
#         self.mathmark=0
#         self.sciencemark=0
#         self.englishmark=0
#     def add_marks(self,sub,marks):
#         if sub=="math":
#             self.mathmark=marks
#         elif sub=="sci":
#             self.sciencemark=marks
#         elif sub=="eng":
#             self.englishmark=marks
#         else:
#             print("invalid ")
#     def cal_avg(self):
#         totalmarks=self.mathmark+self.sciencemark+self.englishmark
#         self.avg=totalmarks/3
#     def display(self):
#         print(f"student name:{self.name}" )
#         print(f"student id:{self.student_id}")
#         print(f"student math marks:{self.mathmark}")
#         print(f"student sci marks:{self.sciencemark}")
#         print(f"student eng marks:{self.englishmark}")
#         print(f"student avg:{self.avg}")
# student=clsschool("Chaitali",101)
# student.add_marks('math',99)
# student.add_marks('sci',98)
# student.add_marks('eng',98)
# student.cal_avg()
# student.display()
#
#
# if __name__=="__main__":
#     #constructor
#     student = clsschool(name:"Neha",student_id:100)
#     student1 = clsschool(name:"Chatali",student_id:300)
#     #objphonebook1.display_phonebook()
#     #objphonebook2.display_phonebook()
#
#
# listobjlist=[]
#
# listobjlist.append(objphonebook1)
# listobjlist.append(objphonebook2)
# for items in listobjlist:
   #


class clsschool:
        school_name = "Green_Valley_High_School"

        def __init__(self, name, student_id):
            self.name = name
            self.student_id = student_id
            self.mathmark = 0
            self.sciencemark = 0
            self.englishmark = 0
            self.avg = 0  # Initialize avg here

        def add_marks(self, sub, marks):
            if sub == "math":
                self.mathmark = marks
            elif sub == "sci":
                self.sciencemark = marks
            elif sub == "eng":
                self.englishmark = marks
            else:
                print("Invalid subject")

        def cal_avg(self):
            totalmarks = self.mathmark + self.sciencemark + self.englishmark
            self.avg = totalmarks / 3 if totalmarks > 0 else 0  # Avoid division by zero
        # def topper(self):
        #     top=list_of_students[0]
        #     for top in list_of_students


        def display(self):
            print(f"Student Name: {self.name}")
            print(f"Student ID: {self.student_id}")
            print(f"Math Marks: {self.mathmark}")
            print(f"Science Marks: {self.sciencemark}")
            print(f"English Marks: {self.englishmark}")
            print(f"Average Marks: {self.avg:.2f}")  # Format to 2 decimal places
            print()  # For better readability


if __name__ == "__main__":
        # Creating student instances
        student1 = clsschool(name="Chaitali", student_id=101)
        student1.add_marks('math', 99)
        student1.add_marks('sci', 98)
        student1.add_marks('eng', 98)
        student1.cal_avg()
        student1.display()

        student2 = clsschool(name="Neha", student_id=100)
        student2.add_marks('math', 85)
        student2.add_marks('sci', 90)
        student2.add_marks('eng', 88)
        student2.cal_avg()
        student2.display()

        # Creating a list to store student objects
        list_of_students ={}

        # Displaying all students
        for key,value  in list_of_students:
            print(f"key are {key}:{valu}")
            student.display()


