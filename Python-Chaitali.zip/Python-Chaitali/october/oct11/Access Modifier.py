#Acess modifiers
#public variable
#protected var.(e.g= _varName)
#private variable(e.g __VarName
#_ParentA__num1

class car:
    def __init__(self,make,model,year):
        self.make=make #public
        self._model=model#protected
        self.__year=year
    def display_info(self):
        return f"{self.make} {self._model} {self.__year}"
    def set_year(self,year):
        self.__year=year


my_car=car("Toyota","corolla",2020)
print(my_car.display_info())#accessing through public method
my_car.set_year(1999)
print(my_car.display_info())

#my_car.__year=1999 this will not affect  private variable