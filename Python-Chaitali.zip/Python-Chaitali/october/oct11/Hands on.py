

#
# class parent_A:
#     def __init__(self,num1,num2):
#         self.num1=num1
#         self.num2=num2
#     def math_opeartion(self):
#         add= self.num1+self.num2
#         print(add)
# class child_B(parent_A):
#     def math_opeartion(self):
#         super().math_opeartion()
#         mul=self.num1*self.num2
#         print(mul)
# obj=child_B(2,3)
# print(obj.math_opeartion())
#



#
# class ParentA:
#     def __init__(self, num1, num2):
#         self.__num1 = num1
#         self.__num2 = num2
#
#     def math_operation(self):
#         add = self.__num1 + self.__num2
#         return add  # Return the result instead of printing
#
# class ChildB(ParentA):
#     def math_operation(self):
#         add_result = super().math_operation()  # Call the parent method
#         # Accessing the private variables using a getter method
#         mul = self._ParentA__num1 * self._ParentA__num2  # Accessing private variables directly
#         return add_result, mul  # Return both results
#
# # Create an instance of ChildB
# obj = ChildB(2, 3)
# results = obj.math_operation()
# print(f"Addition: {results[0]}, Multiplication: {results[1]}")



# class parent_A:
#     # _protected_n1=5
#     # _protected_n2=3
#     def __init__(self):
#         self._protected_n1=10
#         self._protected_n2=20
#     def math_operation(self):
#         print("this is math opeartion")
# class child_B(parent_A):
#     def math_operation(self):
#
#         mul=self._protected_n1*self._protected_n2
#         print(mul)
# obj=child_B()
# print(obj.math_operation())


#
class parent_A:

    def __init__(self):
        self.n1=10
        self.n2=2
    def math_operation(self):
        pass
class child_B(parent_A):
    def math_operation(self):
        mul=self.n1*self.n2
        print(mul)
if __name__ == "__main__":
    obj=child_B()
    print(obj.math_operation()) ## to use public variable mention created object ,it will call to child then parent
    mul1 = obj.n1 * obj.n2
    print(mul1)
