#Abstraction is hiding attribute
#Cannot instantiated directly



# from abc import ABC, abstractmethod
# class animal(ABC):
#     @abstractmethod
#     def sound(self):
#         pass
# class dog(animal):
#     def sound(self):
#         return "woof"
# class cat(animal):
#     def sound(self):
#         return "meow"
# objdog=dog()
# print(objdog.sound())
#
# from abc import ABC , abstractmethod
# class vehicle(ABC):
#     @abstractmethod
#     def start(self):
#         pass
#
#     @abstractmethod
#     def stop(self):
#         pass
# class car(vehicle):
#     def start(self):
#         print(" car has 4 wheels")
#     def stop(self):
#         print("car can stop")
# class bike(vehicle):
#     def start(self):
#         print(" bike has 2 wheels")
#     def stop(self):
#         print(" bike can stop")
# class bus(vehicle):
#     def start(self):
#         print(" bus has 4 wheels")
#     def stop(self):
#         print(" bus stopn on bus stop")
# class garage:
#     def __init__(self):
#         self.vehicles=[]
#
#     def add(self,vehicle):
#         self.vehicles.append(vehicle)
#
#     def operate(self):
#         for vehicle in self.vehicles:
#             vehicle.start()
#             vehicle.stop()
#
# garage1=garage()
# car1=car()
# bike1=bike()
# bus1=bus()
#
# # garage1.add(car)
# # garage1.add(bike)
# # garage1.add(bus)
# #
# # garage1.operate()


#
# from abc import ABC, abstractmethod
#
# class Vehicle(ABC):
#     @abstractmethod
#     def start(self):
#         pass
#
#     @abstractmethod
#     def stop(self):
#         pass
#
# class Car(Vehicle):
#     def start(self):
#         print("Car has 4 wheels")
#     def stop(self):
#         print("Car can stop")
#
# class Bike(Vehicle):
#     def start(self):
#         print("Bike has 2 wheels")
#     def stop(self):
#         print("Bike can stop")
#
# class Bus(Vehicle):
#     def start(self):
#         print("Bus has 4 wheels")
#     def stop(self):
#         print("Bus stops at bus stop")
#
# class Garage:
#     def __init__(self):
#         self.vehicles = []
#
#     def add(self, vehicle):
#         self.vehicles.append(vehicle)
#
#     def operate(self):
#         for vehicle in self.vehicles:
#             vehicle.start()
#             vehicle.stop()
#
#
# garage1 = Garage()
# car1 = Car()
# bike1 = Bike()
# bus1 = Bus()
#
#
# garage1.add(car1)
# garage1.add(bike1)
# garage1.add(bus1)
#
#
# print(garage1.operate())









class product:
    def __init__(self, name,price,stock):
        self.name=name
        self.price=price
        self.stock=stock
    def get_details(self):
        return { 'name':self.name,'price':self.price,'stock':self.price}
class user:
    def __init__(self, name):
        self.name = name
        self.cart = []
    def add_to_cart(self,product):
        if product.stock>0:
            self.cart.append(product)
            product.stock-=1
            print(f"{product.name} addedd.....")
        else:
            print(f"{product.name} not in stock")
    def view_cart(self):
        if not self.cart:
            print("empty cart")
        else:
            total=0
            print("your cart contain:")
            for item in self.cart:
                print(f"{item.name}:Rs{item.price}")
                total+=item.price
            print(f"total price is Rs.{total}")

class GuestUser(user):
    def __init__(self,name):
        super().__init__(name)
    def checkout(self):
        print("Guest cannot procced to checkout")
class Register(user):
    def __init__(self,name,address):
        super().__init__(name)
        self.address = address
    def checkout(self):
        if not self.cart:
            print("your cart is empty ")
        else:
            total = 0
            print(f"process to checkout for {self.name} at {self.address}:")
            for item in self.cart:
                print(f"{item.name}:Rs{item.price}")
                total += item.price
            print(f"total price is Rs.{total}")
            self.cart.clear()




product1=product("bat",20,2)
product2=product("ball",10,3)
user1=user("chaitali")
user1.add_to_cart(product1)
user1.add_to_cart((product2))
user1.view_cart()

guest1=GuestUser("GuestNehidi")
guest1.add_to_cart(product1)
guest1.add_to_cart(product2)
guest1.view_cart()
guest1.checkout()

register1=Register("vaishi","pune")
register1.add_to_cart(product1)
register1.add_to_cart(product2)
register1.view_cart()
register1.checkout()


