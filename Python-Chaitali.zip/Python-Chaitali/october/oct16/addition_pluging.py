from pluginInterface import PluginInterface
class AddPlugin(PluginInterface):
    def execute(self, a, b):
        return a + b
if __name__ == "__main__":
    print(__name__)
    add_plugin=AddPlugin()
    result=add_plugin.execute(10,20)
    
    print(f"The sum is : {result}")