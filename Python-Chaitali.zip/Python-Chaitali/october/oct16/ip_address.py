# from ipaddress import ip_address
#
# from numpy.typing.mypy_plugin import plugin
#
#
# def check(ip_address):
#     response = plugin.check(ip_address)
#     return response
# def process(input_file,output_file):
#     with open(input_file,'r') as file:
#         ip_address = file.readlines()
#     with open(output_file,'w') as file:
#         for ip  in ip_address:
#             ip = ip.strip()
#             if ip:
#                 result = check(ip)
#                 file.write(f" {ip}: {result}:/n")
#                 print(f" {ip}: {result}")
#                 input_file = 'input_ips.txt'
#                 output_file = 'output_results.txt'
#                 process(input_file,output_file)

from ipaddress import ip_address, AddressValueError


def check(ip):
    # Directly check if the IP address is valid
    return "Valid" if isinstance(ip_address(ip), ip_address) else "Invalid"


def process(input_file, output_file):
    with open(input_file, 'r') as file:
        ip_addresses = file.readlines()

    with open(output_file, 'w') as file:
        for ip in ip_addresses:
            ip = ip.strip()
            if ip:  # Check if the line is not empty
                result = check(ip)
                file.write(f"{ip}: {result}\n")
                print(f"{ip}: {result}")


# Example usage
if __name__ == "__main__":
    input_file = 'input_ips.txt'
    output_file = 'output_results.txt'
    process(input_file, output_file)



