import os
from pluginInterface import PluginInterface
class PingPlugin(PluginInterface):
    def execute(self,address):
        # for linux use "ping -c 1"
        response = os.system(f"ping -n 1 {address}")
        if response == 0:
            return f"{address} is reachable"
        else:
            return f"{address} is not reachable"


