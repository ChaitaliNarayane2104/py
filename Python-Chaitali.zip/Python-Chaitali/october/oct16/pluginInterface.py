class PluginInterface:
    def execute(self,a,b):
        raise NotImplementedError("plugin must implement") #This line raises an error if execute is called directly on PluginInterface