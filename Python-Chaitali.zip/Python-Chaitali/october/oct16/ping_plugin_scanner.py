from ping_plugin import PingPlugin
def main():
    operations ={
        "1":PingPlugin(),

    }
    print("Choose a netwoek opeartion")
    print("1.ping a server")
    print("2. check if port is open")
    print("3.resolve a hostname")

    ch =input(" enter the num of corressponding tothe operation")
    if ch  not in operations:
        print("invalid choice")
        return
    if  ch == "1":
        address =input("enter the ip address or hostname to ping")
        result = operations[ch].execute(address)
    elif ch =="2":
        address = input(" enter the ip address to check")
        port = int(input(" enter the port no."))
        result = operations[ch].execute(address,port)
    elif ch == "3":
        hostname =input(" eter the hostname to resolve:")
        result = operations[ch].execute(hostname)
    print(f" result: {result}")

if __name__ == "__main__":
    print("in main")
    main()