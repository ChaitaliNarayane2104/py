
from addition_pluging import AddPlugin
def main():
    add_plugin=AddPlugin()
    v1=int(input("enter the 1st number"))
    v2=int(input("enter 2nd "))
    result=add_plugin.execute(v1,v2)
    print(f" the sum of {v1} and {v2} is : {result}")
if __name__=="__main__":
    main()