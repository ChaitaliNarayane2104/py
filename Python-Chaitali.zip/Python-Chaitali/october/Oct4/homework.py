def manage_votes():
    movie_votes = {}

    while True:
        print("\nMenu:")
        print("1. Add a new movie")
        print("2. Vote for a movie")
        print("3. Remove a movie")
        print("4. Display voting results")
        print("5. Find the top movie")
        print("6. Exit")

        choice = input("Enter your choice (1-6): ")

        if choice == "1":

            movie = input("Enter movie name to add: ")
            if movie not in movie_votes:
                movie_votes[movie] = 0
                print(f"{movie} added with 0 votes.")
            else:
                print(f"{movie} is already in the list.")

        elif choice == "2":

            movie = input("Enter movie name to vote for: ")
            if movie in movie_votes:
                movie_votes[movie] += 1
                print(f"Vote added for {movie}.")
            else:
                print(f"{movie} is not in the list.")

        elif choice == "3":

            movie = input("Enter movie name to remove: ")
            if movie in movie_votes:
                del movie_votes[movie]
                print(f"{movie} has been removed.")
            else:
                print(f"{movie} is not in the list.")

        elif choice == "4":

            if movie_votes:
                print("\nVoting Results:")
                for movie, votes in movie_votes.items():
                    print(f"{movie}: {votes} votes")
            else:
                print("No movies in the list.")

        elif choice == "5":

            if movie_votes:
                top_movie = max(movie_votes, key=movie_votes.get)
                print(f"The top movie is {top_movie} with {movie_votes[top_movie]} votes.")
            else:
                print("No movies in the list.")

        elif choice == "6":

            print("Exiting the program.")
            break

        else:
            print("Invalid choice. Please try again.")



manage_votes()