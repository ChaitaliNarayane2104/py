def recursive_sum(numbers):
    print(numbers)
    if not numbers:
        return 0
    else:
        return numbers[0]+recursive_sum(numbers[1:])
numbers=[1,2,3,4,5]
result=recursive_sum(numbers)
print("the sum of the list is :", result)
#
#0+1,2,3,4,5
#1+2,3,4,5