#lambda Function
# str=input("enter the string")
# def len1():
#     x=len(str)
#     return x
# print(len1())
#
# def find_string_length(strString):
#     return (len(strString))
# str_len=find_string_length("table")
# print(str_len)
#
# print()
# str="table"
# str_len=lambda str:len(str)
# print(str_len(str))
#


#
# def addnumber(num1,num2):
#      return(num1+num2)
# result= (addnumber(5,4))
# print(result)
#
#
# print((lambda a,b : a+b)(5,3))



# cube = lambda x:x*x*x
# print(cube(3))


# def my_lambda_fucn(fuc_name,lstnums):
#     lsresult=[]
#     for item in lstnums:
#          new_item =fuc_name(item)
#          lsresult.append(new_item)
#     return lsresult
# lsnum=[2,3,4,5,6]
# lstCubed=my_lambda_fucn(lambda x:x**3,lsnum)
# print(lstCubed)

# def my_lambda_fucn(fuc_name,lstnums):
#     lsresult=[]
#     for item in lstnums:
#          new_item =fuc_name(item)
#          lsresult.append(new_item)
#     return lsresult
# lsnum=[2,3,4,5,6]
# lst=my_lambda_fucn(lambda x:x*3,lsnum)
# print(lst)

# list=[]
# num_lst=[2,3,4,5,6]
# lst=(lambda x:x*3,num_lst)
# x=list.append(lst)
# print(x)

# lst_nums=[2,3,4,3]
# lstCube=map(lambda x:x**3,l st_nums)
# print(list(lstCube))


#( lambda variable: operation,pass arguments)
#print((lambda x,y:"y is greater " if x<y else "x is greater ")(6,5)


# list1=[]
# lst_nums=[2,-3,4,3]
# for i in lst_nums:
#     y=(lambda x:"positive " if i>0 else "negative")([2,3,4,3])
#     list1.append(y)
# print(list1)

# map() used as iteration in loop also act as function
list1=[]
lst_nums=[2,-3,4,3]
y=map((lambda x:"positive " if x>0 else "negative"),(lst_nums))
print(list(y))