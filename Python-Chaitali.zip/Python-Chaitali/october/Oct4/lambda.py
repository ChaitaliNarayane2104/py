#lambda Function
# str=input("enter the string")
# def len1():
#     x=len(str)
#     return x
# print(len1())
#
# def find_string_length(strString):
#     return (len(strString))
# str_len=find_string_length("table")
# print(str_len)
#
# print()
# str="table"
# str_len=lambda str:len(str)
# print(str_len(str))
#


#
# def addnumber(num1,num2):
#      return(num1+num2)
# result= (addnumber(5,4))
# print(result)
#
#
# print((lambda a,b : a+b)(5,3))



# cube = lambda x:x*x*x
# print(cube(3))


# def my_lambda_fucn(fuc_name,lstnums):
#     lsresult=[]
#     for item in lstnums:
#          new_items =fuc_name(item)
#  lsresult