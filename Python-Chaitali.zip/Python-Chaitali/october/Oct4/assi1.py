str=input("enter the string")
def len1():
    x=len(str)
    return x
print(len1())