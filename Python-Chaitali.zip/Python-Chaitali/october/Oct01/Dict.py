dict={'a':1,'b':2,'c':4}
print(dict)

print()
print(dict['c'])
print(dict.get('c'))

print("value that a dict can take")
mydict={"intvalue":42,
        "stringvalue":"chaitali neha",
        "tuplevalue":(1,2,3),
        "listvalue":["a","test","string"],
        "nesteddict":{"key1":"value1","key2":"value2","key3":3}}
print("checking for keys")
if 2 in dict:
    print("key \'2\' is present")
else:
    print("key \'2\' is absent")


