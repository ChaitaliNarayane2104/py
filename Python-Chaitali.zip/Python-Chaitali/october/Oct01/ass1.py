# #dict={1:1,2:8,3:27,4:64,5:125}
# dict={}
# for key in range(6):
#     for values in dict:
#         print({key},{key**3})
# print(dict)
# # for key,value in dict.items():
# #     print(f"{key},{value}")
# # print()
#
# dict={}
# for i in range(6):
#     dict.update({i:i**3})
# print(dict)
#


#
# dict={}
# for i in range(ord('a') ,ord('e')+1):
#     # dict.update({chr(i):ord(chr(i))})
#     dict.update({chr(i): i})
# print(dict)
#
# dict={}
#
# dict["name"] =input("enter the name")
# dict["roll_no"]=int(input("enter the roll_no"))
#
# english =int(input("enter the englis score"))
# science =int(input("enter the science score"))
# math =int(input("enter the math score"))
#
# dict["avgerage"]=(science+math+english)//3
#
# percentage=(science + math + english) / 300 * 100
# dict["percentage"]=round(percentage,2)
#
# print(dict)

# dict={}
# dict["items"]=input("enter the item")
# #dict["Quantity"]=int(input("enter the quantity"))
# #dict["price"]=int(input("enter the price"))
# quantity=int(input("enter the quantity"))
# price=int(input("enter the price"))
# #i=1
# #j=str(i)
# for i in dict:
#     dict.update({items:})
#     items={}
#     for keys in items:
#         items.update({quantity:price})
# print(dict)
#


shop={}
store_dict={}
item = input("enter the items")
while True:
    store_dict["Quantity"]=input("enter the quntity")
    store_dict["price"]=input("enter the price")
    shop.update({item:store_dict})
    print(shop)
    ch =input("do you want to update quantity nd price[y/n")
    if ch != 'y':
        shop.update({item: store_dict})
        break
