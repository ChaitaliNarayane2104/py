dict={'a':1,'b':2,'c':4}
print(dict)

print()
print(dict['c'])
print(dict.get('c'))

print("value that a dict can take")
mydict={"intvalue":42,
        "stringvalue":"chaitali neha",
        "tuplevalue":(1,2,3),
        "listvalue":["a","test","string"],
        "nesteddict":{"key1":"value1","key2":"value2","key3":3}}
print()

# print("pop")
# dictval=dict.pop(1)
# print(dictval)
# print(dict)
# print()

print("checking for keys")
if 2 in dict:
    print("key \'2\' is present")
else:
    print("key \'2\' is absent")
print()

print("Itrerate over key")
for key in dict:
    print(key)
print()

print("itrerate over value")
for value in dict.values():
    print(value)
print()

print("itrearting over key value pair")
for key,value in dict.items():
    print(f"{key},{value}")
print()

print("Merging dictionary")
dict1={'a':1,'b':2,'c':4}
dict2={'a':5,'b':6,'c':7}
print("using update()")
dict1.update(dict2)
print(dict1)
print()

print("Clearing")
print(dict)
dict.clear()
print("After clearing")
print(dict)