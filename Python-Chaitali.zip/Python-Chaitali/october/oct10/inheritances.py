# class Animal:
#     def __init__(self,name):
#         self.name=name
#     def speak(self):
#         return f"{self.name} makes a sound"
# class dog(Animal):
#     def speak(self):
#             return f"{self.name} says woof"
# class cat(Animal):
#     def speak(self):
#         return f"{self.name} says meow"
# dog =dog("jonny")
# cat = cat("bunny")
# print(dog.speak())
# print(cat.speak())
#
#
# class ShapeArea:
#     def __init__(self, shape):
#         self.shape = shape
#
#     def area(self):
#         return f"{self.shape} has area"
#
# class Square(ShapeArea):
#     def __init__(self, side):
#         super().__init__("Square")
#         self.side = side
#
#     def area(self):
#         area1 = self.side ** 2
#         return f"{self.shape} has area {area1}"
#
# class Rectangle(ShapeArea):
#     def __init__(self, length, width):
#         super().__init__("Rectangle")
#         self.length = length
#         self.width = width
#
#     def area(self):
#         area2 = self.length * self.width
#         return f"{self.shape} has area {area2}"
#
# class Circle(ShapeArea):
#     def __init__(self, radius):
#         super().__init__("Circle")
#         self.radius = radius
#
#     def area(self):
#         area3 = 3.14 * (self.radius ** 2)
#         return f"{self.shape} has area {area3}"
#
# # Create instances and print areas
# area1 = Square(2)
# print(area1.area())
#
# area2 = Rectangle(4, 8)
# print(area2.area())
#
# area3 = Circle(2)
# print(area3.area())



### multilevel inheritances ####
#
# class animal:
#     def speak(self):
#         print("animal speaks")
# class dog(animal):
#     def walk(self):
#         print(" dogs walk")
# class cat(dog):
#     def bark(self):
#         print("dogs meow!!")
# obj=cat()
# print(obj.bark())
# print(obj.walk())
# print(obj.speak())


### multiple inheritances####
# class swimmer:
#     def swim(self):
#         print("swimmer swims")
# class flyer:
#     def fly(self):
#         print(" flyer flies")
# class Duck(swimmer,flyer):
#     def quack(self):
#         print("duck quaks")
# duck =Duck()
# duck.quack()
# duck.fly()
# duck.swim()

### hieractical ##

# class animal:
#     def __init__(self,name):
#         self.name=name
#     def speak(self):
#         pass
# class Dog(animal):
#     def speak(self):
#         return f" {self.name} says moew"
# class Birds(animal):
#     def speak(self):
#         return f" {self.name} says chirp"
# dog = Dog("buddy")
# birds= Birds("tweety")
# print(dog.speak())
# print(birds.speak())


