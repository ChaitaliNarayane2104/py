# class Animal:
#     def __init__(self,name):
#         print("in the constructor of animal")
#         self.name=name
#     def speak(self):
#         print("animal have sound")
#         return f"{self.name} makes a sound"
# class dog(Animal):
#     def __init__(self,name):
#         print("in the constructor of dog")
#         self.name=name
#     def speak(self):
#             return f"{self.name} says woof"
# dog =dog("jonny")
# print(dog.speak())

#
# class car:
#     def __init__(self,dist_travel,make,mode):
#         self.dist_travel=dist_travel
#         self.make=make
#         self.mode=mode
#         def cal_mileage(self):
#             print(f" calculate milege for {self.make},{self.mode}")

# class electric_car(car):
#     def __init__(self,make,mode,dist_travel,energy):
#         super().__init__(make,mode,dist_travel)
#         self.energy=energy
#     def cal_mileage(self):
#         mileage=self.dist_travel/self.energy
#         print(f" {mileage} of electric car")
# class fuel_car(car):
#     def __init__(self,make,mode,dist_travel,fuel):
#         super().__init__(make,mode,dist_travel)
#         self.fuel=fuel
#         def cal_mileage(self):
#             fuel_consumed = self.dist_travel / self.fuel
#             print(f" {fuel_consumed} of electric car")
# if __name__ == "__main__":
#     tesla = electric_car("tesla","model s","400","75")
#     bmw = electric_car("bmw", "x5", "600", "85")
#     tesla.cal_mileage()
#     bmw.cal_mileage()




#
#
# class Car:
#     def __init__(self, make, mode, dist_travel):
#         self.dist_travel = dist_travel
#         self.make = make
#         self.mode = mode
#
#     def cal_mileage(self):
#         print(f"Calculating mileage for {self.make}, {self.mode}")
#
# class ElectricCar(Car):
#     def __init__(self, make, mode, dist_travel, energy):
#         #super().__init__(make, mode, dist_travel)
#
#         self.dist_travel = dist_travel
#         self.make = make
#         self.mode = mode
#         self.energy = energy
#
#     def cal_mileage(self):
#         super().cal_mileage()
#         mileage = self.dist_travel / self.energy
#         print(f"Mileage of electric car {self.make} {self.mode}: {mileage}")
#
# class FuelCar(Car):
#     def __init__(self, make, mode, dist_travel, fuel):
#         #super().__init__(make, mode, dist_travel)
#         self.dist_travel = dist_travel
#         self.make = make
#         self.mode = mode
#         self.fuel = fuel
#
#     def cal_mileage(self):
#         super().cal_mileage() # super() call to parent cls cal_mileage
#         fuel_consumed = self.dist_travel / self.fuel
#         print(f"Mileage of fuel {self.make} {self.mode}: {fuel_consumed} ")
#
# if __name__ == "__main__":
#     tesla = ElectricCar("Tesla", "Model S", 400, 75)
#     bmw = FuelCar("BMW", "X5", 600, 20)
#
#     tesla.cal_mileage()
#     bmw.cal_mileage()



class A:
    def __init__(self):
        self.num1 = 2
        self.num2 =10

    def math_operation(self):
        add = self.num1 + self.num2
        print(f"Math operation of {self.num1}, {self.num2} is {add}")

class B(A):  # Inherit from class A
    def math_operation(self):
        super().math_operation()  # Call the parent class's method # whatever done in parent cls that will give o/p
        mul = self.num1 * self.num2  # Use inherited attributes
        print(f"Multiplication of two numbers is {mul}")

if __name__ == "__main__":
    # Create an instance of class B
    number2 = B()  # Pass integers, not strings
    number2.math_operation()  # Call math_operation on the instance of B
