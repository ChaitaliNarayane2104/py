import csv
data = [
    ['name', 'age', 'grade'],
    ['neha', '24', 'a'],
    ['chaitali', '21', 'b'],
    ['vaishali', '25', 'c']
]
# Write to CSV file
with open('new_student.csv', mode='w', newline='', encoding='utf-8') as file:
    csv_writer = csv.writer(file)
    csv_writer.writerows(data)
    print("data written to new student.csv")


# Read from CSV file
with open('new_student.csv', mode='r', encoding='utf-8') as file:
    csv_reader = csv.reader(file)
    header = next(csv_reader)
    print(f"Header: {header}")
    for row in csv_reader:
        print(row)
