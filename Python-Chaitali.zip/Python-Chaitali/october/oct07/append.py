# # def write_list_to_file(filename:str,mylist:list):
# #     with open(filename,'a') as file:
# #         for item in mylist:
# #             file.write(f"{item}\n")
# # mylist=['apple','banana','cherry']
# # write_list_to_file('example.txt',mylist)

# def write_dict_to_file(filename:str,mydict:dict):
#     with open(filename,'a') as file:
#         for key,value in mydict.items():
#             file.write(f"{key}={value}\n")
# mydict={'apple':2,'banana':3,'cherry':4}
# write_dict_to_file('example.txt',mydict)


dict={}
dict['name']=input("enter the name")
dict['Roll']=int(input("enter the roll"))
dict['sci']=int(input("enter the science"))
dict['math']=int(input("enter the math"))
dict['english']=int(input("enter the science"))
dict["avgerage"]=(dict['sci']+dict['math']+dict['english'])//3
#dict.update()
print(dict)


def write_to_file(filename: str, data:dict):
    with open(filename, 'a') as file:
        for key,value in data.items():
            file.write(f"{key}: {value} ")
        file.write(f"\n")
        #file.write(data)
    print(f"data writtemn to {filename} successfully")


filename = 'example2.txt'
write_to_file(filename,dict)