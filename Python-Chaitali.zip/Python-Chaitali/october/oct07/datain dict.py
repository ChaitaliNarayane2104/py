import csv

data={'name':'alice','age':30,'city':'new york'}
filename='students.csv'
with open(filename,mode='w',newline='') as file :
    fieldnames=data.keys()
    writer = csv.DictWriter(file, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerow(data)