def write_to_file(filename,data):
        with open(filename,'w') as file:
            file.write(data)
        print(f"data writtemn to {filename} successfully")
filename='example.txt'
write_to_file(filename,"Hello, this is 1st line")


def read_from_file(filename):
    try:
        with open(filename,'r') as file:
            content = file.read()
        print(f"contents of{filename}:\n{content}")

    except FileNotFoundError:
        print(f"error: the file'{filename}' does not exist")
filename='example.txt'
read_from_file(filename)


def append_to_file(filename,data):
    with open(filename,'a') as file:
        file.write(data)
    print(f"data appended to {filename} successfully.")
filename='example.txt'
append_to_file(filename," appending a new line to line .\n")