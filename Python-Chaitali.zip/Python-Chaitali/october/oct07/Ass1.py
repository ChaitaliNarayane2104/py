# def write_to_file(filename, data):
#     with open(filename, 'w') as file:
#         file.write(data)
#     print(f"data writtemn to {filename} successfully")
#
#
# filename = 'a.txt'
# write_to_file(filename, "Hello, fake peoples in this class")
# def read_from_file(filename):
#     try:
#         with open(filename,'r') as file:
#             content = file.read()
#         print(f"contents of{filename}:\n{content}")
#
#     except FileNotFoundError:
#         print(f"error: the file'{filename}' does not exist")
# filename='a.txt'
# read_from_file(filename)

#
# def write_to_file(filename, data):
#     with open(filename, 'w') as file:
#         file.write(data)
#     print(f"data writtemn to {filename} successfully")
#
#
# filename = 'a.csv'
# write_to_file(filename, "Hello, fake peoples in this class")
# def read_from_file(filename):
#     try:
#         with open(filename,'r') as file:
#             content = file.read()
#         print(f"contents of{filename}:\n{content}")
#
#     except FileNotFoundError:
#         print(f"error: the file'{filename}' does not exist")
# filename='a.csv'
# read_from_file(filename)


import csv

students=[]
for i in range(3):
    name =str(input("enter the name"))
    age =input("enter the age")
    mark=input("enter the marks")
    students.append([name,age,mark])

with open('new_student.csv', mode='w', newline='', encoding='utf-8') as file:
    csv_writer = csv.writer(file)
    csv_writer.writerows(students)
    print("data written to new student.csv")

with open('new_student.csv', mode='r', encoding='utf-8') as file:
    csv_reader = csv.reader(file)
    header = next(csv_reader)
    print(f" {header}")
    for row in csv_reader:
        print(row)
