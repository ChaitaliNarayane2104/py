class Url:
    url_dict={}
    base_url="http://short.url/"
    def add_url(self,original_url):
        if original_url in self.url_dict:
            print("url is already exist")
            return self.url_dict[original_url]
        else:
            short_url=self.base_url +str(len(self.url_dict)+ 1)