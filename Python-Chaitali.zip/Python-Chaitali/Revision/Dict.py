dict1={"Mayuri":89,"Pravin":92,"Ketaki":95,"Chinmay":99}
c=0

print("Total Number of Students is:{}".format(c))
print(len(dict1))
dict1["Pravin"]=66
print("Updated list is:{}".format(dict1))
dict1.pop("Ketaki")
print(dict1)
x=dict(sorted(dict1.items()))
print(x)