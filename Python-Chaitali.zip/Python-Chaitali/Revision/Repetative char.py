import re

string = input("enter the string")
new_string = re.sub(r'(.)\1+', r'\1', string) #. means it capture the char.
print(new_string)

# re.sub(r'(.)\1+', r'\1', string):
# (.): Captures any character.
# \1+: Matches one or more occurrences of that character.
# r'\1': Replaces the matched sequence with just one occurrence of the character.

