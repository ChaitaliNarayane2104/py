Music_PlayList=[]
def Add():
    while True:
        song=input(str("enter the song title"))
        Music_PlayList.append(song)
        ch1=input("Do you want to add another song[y/n]:")
        if ch1 != "y":
            break
    print(Music_PlayList)

def Remove():
    remove_song=input("Which song do you want to remove:")
    if remove_song in Music_PlayList:
        Music_PlayList.remove(remove_song)
        print(f"{remove_song} has been removed.")
        print(Music_PlayList)
while True:
    ch=input("1: Add_Songs\n"
             "2:Remove song\n"
             "3:View all song\n"
             "4:Slice playlist\n")

    if ch=="1":
        print(Add())
    elif ch=="2":
        print(Remove())
    elif ch == "3":
        print(Music_PlayList)
    ch2=input("Do you want perform anothher opearation[y/n]")
    if ch2 != "y":
        break
