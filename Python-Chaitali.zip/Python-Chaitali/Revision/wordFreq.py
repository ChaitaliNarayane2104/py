# word_count={}
# def count_word():
#     str1=input("enter the sentence:")
#     for i in str1:
#         x=len(str1.split())
#         for i,x in
#         return x
# print(count_word())

# print("itrearting over key value pair")
# for key,value in dict.items():
#     print(f"{key},{value}")
# print()

#
# word_count={}
# str1=input("enter the sentence:")
# for key,value in str1.items():
#     print(f"{key},{value}")

def count_words(sentence):
    words = sentence.split()
    word_count = {}

    for word in words:
        word = word.lower()
        if word in word_count:
            word_count[word] += 1
        else:
            word_count[word] = 1

    return word_count


def print_word_frequencies(word_count):
    for word, count in word_count.items():
        print(f"{word}: {count}")


sentence = input("Enter a sentence: ")

word_count = count_words(sentence)
print_word_frequencies(word_count)