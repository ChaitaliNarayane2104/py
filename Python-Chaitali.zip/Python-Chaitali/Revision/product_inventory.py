import csv

product_inventory = {}

def add_product(inventory, product_id, product_tuple):
    inventory[product_id] = product_tuple
    print(f"Product {product_tuple[0]} added successfully!")

def update_quantity(inventory, product_id, new_quantity):
    if product_id in inventory:
        product_name, price, _ = inventory[product_id]
        inventory[product_id] = (product_name, price, new_quantity)
        print(f"Quantity of product {product_name} updated to {new_quantity}.")
    else:
        print("Product ID not found.")

def display_products(inventory):
    print("Product Inventory:")
    print("Product ID | Product Name | Price | Quantity | Total Price")
    for product_id, product_details in inventory.items():
        product_name, price, quantity = product_details
        total_price = price * quantity
        print(f"{product_id} | {product_name} | ${price:.2f} | {quantity} | ${total_price:.2f}")

def save_to_csv(inventory, filename="product_inventory.csv"):
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["Product ID", "Product Name", "Price", "Quantity", "Total Price"])

        for product_id, product_details in inventory.items():
            product_name, price, quantity = product_details
            total_price = price * quantity
            writer.writerow([product_id, product_name, price, quantity, total_price])
    print(f"Inventory saved to {filename}.")

if __name__ == "_main_":
    add_product(product_inventory, 101, ("Laptop", 1000.50, 10))
    add_product(product_inventory, 102, ("Headphones", 150.75, 30))

    update_quantity(product_inventory, 101, 15)

display_products(product_inventory)
save_to_csv(product_inventory)