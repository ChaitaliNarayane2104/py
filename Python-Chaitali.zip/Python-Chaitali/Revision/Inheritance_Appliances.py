class Appliances:
    def __init__(self,brand,power_rating):
        self.brand=brand
        self.power_rating=power_rating
    def energy_usage(self,hours):
        energy=(self.power_rating*hours)/1000
        print(f"enry consumes:{energy} kWh")
    def display(self):
        print(f"this is a {self.brand} appliances")
class WashingMachine(Appliances):
    def __init__(self,brand,power_rating,capacity):
        super().__init__(brand,power_rating)
        self.capacity=capacity
    def display(self):
        print(f"this is a {self.brand} washing machine with {self.capacity} kg capacity")
class Refrigerator(Appliances):
    def __init__(self,brand,power_rating,volume):
        super().__init__(brand,power_rating)
        self.volume=volume
    def display(self):
        print(f"This is a {self.brand} refrigrator with {self.volume} liters capacity")
class Microwave(Appliances):
    def __init__(self,brand,power_rating,power_level):
        super().__init__(brand,power_rating)
        self.power_level=power_level
    def display(self):
        print(f"This {self.brand} microwave with{self.power_level} power level")
obj=WashingMachine("samsung",500,8)
obj.display()
obj.energy_usage(3)

obj1=Refrigerator("LG",150,231)
obj1.display()
obj1.energy_usage(21)

obj2=Microwave("abc",123,211)
obj2.display()
obj2.energy_usage(0.3)


