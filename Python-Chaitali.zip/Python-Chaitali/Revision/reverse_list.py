# list=[100,200,300,400,500]
# print(list[::-1])

# list=[100,200,300,400,500]
# print(max(list))
# print(min(list))

list=[]
for i in range(5):
    list1=input("enter the list items")
    list.append(list1)
print("your list is :{} " .format(max(list)))
print("largest number is :{}".format(min(list)))
print(min(list))