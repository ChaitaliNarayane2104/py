Music_playlist=[]
def Add():
    ch3="y"
    while ch3=="y":
        song=input("enter the song:")
        Music_playlist.append(song)
        print(Music_playlist)
        ch3=input("Do you want enter one more song:[Y/N]:")
def Remove():
    r=input("which song do you want to remove:")
    if r in Music_playlist:
        Music_playlist.remove(r)
        print("{} song is removed".format(r))
        print(Music_playlist)   
def slice():
    a=input("enter the first song:") 
    b=input("enter the 2nd song:") 
    print(Music_playlist[Music_playlist.index(a):Music_playlist.index(b)])
ch="y"
while ch=="y":
    ch=input("1: Add_Songs\n"
             "2:Remove song\n"
             "3:View all song\n"
             "4:Slice playlist\n")


    if ch=="1":
        Add()
    elif ch=="2":
        Remove()
    elif ch == "3":
        print(Music_playlist)
    elif ch=="4":
        slice()
    ch=input("Do you want perform anothher opearation[y/n]")
    