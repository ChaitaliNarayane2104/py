# def write_to_file(filename, data):
#     with open(filename, 'w') as file:
#         file.write(data)
# def read_from_file(filename):
#     with open(filename, 'r') as file:
#         content = file.read()
#         print(f"Contents of {filename}:\n{content}")
#         return content
# def extract_datetime(data):
#     x= "#untild=1#temp=38#date=2024-09-21#time=15:30:00"
#     parts = [i for i in data.split('#') if i]
#     extracted_data = {}
#     for part in parts:
#         key, value = part.split('=')
#         extracted_data[key] = value
#     date = extracted_data.get('date', None)
#     time = extracted_data.get('time', None)
#     return date, time
# filename = 'example.txt'
# data = "#untild=1#temp=38#date=2024-09-21#time=15:30:00"
# write_to_file(filename, data)
# file_content = read_from_file(filename)
# date, time = extract_datetime(file_content)
# print(f"Extracted Date: {date}")
# print(f"Extracted Time: {time}")

def extract_log_details():
    log_entry = "2025-10-10,12:34:56 s_kumar ip:192.168.10.1 login-successfully"
    parts=[i for i in log_entry.split(" ") if i]
    extracted_dict ={}
    extracted_dict["timestamp "]=parts[0]
    extracted_dict["username "] = parts[1]
    extracted_dict["ip address "] = parts[2]
    extracted_dict["Activity "] = parts[3]
    for key,value in extracted_dict.items():
        print(f" {key}: {value}")
extract_log_details()






