def sum_of_digit(n):
    if not n:
        return 0
    else:
        return n%10+sum_of_digit(n//10)
n=123
result=sum_of_digit(n)
print("sum of digit is :",result)