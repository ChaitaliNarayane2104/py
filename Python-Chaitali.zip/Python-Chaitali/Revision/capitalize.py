words=["chaitali","nehha"]
cap_w=list(map(lambda word:word.capitalize(),words))
len1=list(map(lambda x:len(x),words))
print(cap_w)
print("len of string is :{}".format(len1))
