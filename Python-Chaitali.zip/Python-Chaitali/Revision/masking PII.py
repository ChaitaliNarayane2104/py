# ch=input("type 1 for entering email and type 2 for entering credit card number")
# if ch=="1":
#     try:
#         x=str(input("enter the E-mail Id"))
#         print(x[0] + '*' * 3 + x[x.index('@'):])
#     except ValueError:
#         print("plz enter valid email")
#
#
# elif ch=="2":
#     try:
#         y=input("enter the credit card number")
#         print('*' *(len(y)-4)+y[-4:])
#     except ValueError:
#         print("plz enter the valid credit number")
#
#
# def mask_email(email):
#     """Mask the email address except for the first character and domain."""
#     try:
#         masked_email = email[0] + '*' * 3 + email[email.index('@'):]
#         return masked_email
#     except ValueError:
#         return "Please enter a valid email."


def mask_email(email):

    try:
        masked_email = email[0] + '*' * 3 + email[email.index('@'):]
        return masked_email
    except ValueError:
        return


def mask_credit_card(card_number):

    try:
        masked_card = '*' * (len(card_number) - 4) + card_number[-4:]
        return masked_card
    except ValueError:
        return "Please enter a valid credit card number."


def main():
    ch = input("Type 1 for entering email and type 2 for entering credit card number: ")

    if ch == "1":
        email = input("Enter the E-mail ID: ")
        print(mask_email(email))
    elif ch == "2":
        card_number = input("Enter the credit card number: ")
        print(mask_credit_card(card_number))
    else:
        print("Invalid option. Please type 1 or 2.")


if __name__ == "__main__":
    main()


