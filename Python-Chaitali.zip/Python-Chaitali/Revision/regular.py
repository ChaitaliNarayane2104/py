# def write_to_file(filename, data):
#     with open(filename, 'w') as file:
#
#         file.write(data)
#
# filename = 'example.txt'
# write_to_file(filename, "#untild=1#temp=38#date=2024-09-21#time=15:30:00")
#
#
# def read_from_file(filename):
#     with open(filename,'r') as file:
#         content = file.read()
#         print(f"contents of {filename}:\n{content}")
#
#
# filename='example.txt'
# read_from_file(filename)

def write_to_file(filename, data):
    with open(filename, 'w') as file:
        file.write(data)


def read_from_file(filename):
    with open(filename, 'r') as file:
        content = file.read()
        print(f"Contents of {filename}:\n{content}")
        return content


def extract_datetime(data):
    x= "#untild=1#temp=38#date=2024-09-21#time=15:30:00"
    parts = [i for i in data.split('#') if i]


    extracted_data = {}

    for part in parts:
        key, value = part.split('=')
        extracted_data[key] = value

    date = extracted_data.get('date', None)
    time = extracted_data.get('time', None)

    return date, time


filename = 'example.txt'
data = "#untild=1#temp=38#date=2024-09-21#time=15:30:00"
write_to_file(filename, data)


file_content = read_from_file(filename)
date, time = extract_datetime(file_content)

print(f"Extracted Date: {date}")
print(f"Extracted Time: {time}")
