# def find_substring(str1,sub):
#     index= str1.find(sub)
# str1="chaitali"
# sub="tali"
# print(str1.find(sub))

# def find_substring(str1,sub):
#     print(str1.find(sub))
# find_substring("chaitali","tali")

#----------------------------------------------------------------------------------------------------------------
# def format_full_name(str1,str2):
#     print(str2,str1)
# str1 = input("enter the 1st name")
# str2 = input("enter the 2nd number")
# format_full_name(str1,str2)
#-----------------------------------------------------------------------------------------------------------------
# def even_indexed_chars(str1):
#     print(f"Reverse of {str1} is {str1[::-1]}")
#     print(f"{str1[::2]}")
# str1=input("enter the string")
# even_indexed_chars(str1)
#----------------------------------------------------------------------------------------------------------------
def substring_from_end(str1,n):
    print(str1[-n:])
str1=input("enter the name:")
n=int(input("enter the index"))
substring_from_end(str1,n)