# str1="This is fun"
# v=['a','e','i','o','u']
# ans=""
# for char in str1:
#     if char.lower() in v:
#         ans+="abc"
#     else:
#         ans+=char
# print(ans)

str1="This is fun"
v=['a','e','i','o','u']
for i in v:
    str1=str1.replace(i,"abc")
print(str1)
