from mpi4py import MPI


def main():
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()

    if size != 4:
        print("This simulation requires exactly 4 processes.")
        return

    # Define the data each process will send
    data_to_send = rank * 10  # Each process sends its rank multiplied by 10

    # Define the neighbors for a 2x2 mesh topology
    neighbors = {
        0: [1, 2],  # Node 1 connects to Node 2 and Node 3
        1: [0, 3],  # Node 2 connects to Node 1 and Node 4
        2: [0, 3],  # Node 3 connects to Node 1 and Node 4
        3: [1, 2],  # Node 4 connects to Node 2 and Node 3
    }

    # Send data to neighbors
    for neighbor in neighbors[rank]:
        comm.send(data_to_send, dest=neighbor)

    # Receive data from neighbors
    received_data = {}
    for neighbor in neighbors[rank]:
        received_data[neighbor] = comm.recv(source=neighbor)

    print(f"Process {rank} received data: {received_data}")


if __name__ == "__main__":
    main()
