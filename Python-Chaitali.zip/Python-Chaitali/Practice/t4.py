def calculate_average_scores(student_scores):
    """Calculate the average score for each student."""
    average_scores = []
    
    for scores in student_scores:
        average = sum(scores) / len(scores)  # Calculate the average
        average_scores.append(round(average, 2))  # Round to 2 decimal places and add to the list
    
    return average_scores

# Main Program
if __name__ == "__main__":
    # Student Scores
    student_scores = [(85, 90, 78), (92, 88, 91), (70, 75, 80)]
    
    # Calculate average scores
    average_scores = calculate_average_scores(student_scores)
    
    # Print the average scores
    print(f"Student Scores: {student_scores}")
    print(f"Average Scores: {average_scores}")
