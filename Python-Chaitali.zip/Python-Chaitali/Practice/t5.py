# Create a list of the first ten prime numbers
prime_numbers = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]

# Slice the list to obtain the required subsets
first_three_primes = prime_numbers[:3]  # The first three prime numbers
last_two_primes = prime_numbers[-2:]      # The last two prime numbers
middle_primes = prime_numbers[1:-1]      # All prime numbers except the first and last

# Print all the sliced lists
print("First three prime numbers:", first_three_primes)
print("Last two prime numbers:", last_two_primes)
print("All prime numbers except the first and last:", middle_primes)
