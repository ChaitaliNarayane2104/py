# Assignment 8:  
# Write a function translate() that will translate a text.

# Replace every vowel with abc 
# e.g.: “This is fun" should return the string " Thabcs abcs fabcn ". 
# str="This is fun"
# v=['a','e','i','o','u']
# for i in v:
#     str=str.replace(i,"abc")
# print(str)

def translate(v,x,str):
    for i in v:
        str=str.replace(i,x)
    return str
v=['a','e','i','o','u']
str="This is fun" 
print(translate(v,"abc",str))   


