def read_file(filename):
    with open(filename,"r")as file:
        return file.readlines()
def write_file(filename,data):
    with open(filename,"w")as file:
        file.writelines(data)
def replacek(data,old,new):
    return data.replace(new,old)

    
data=read_file("a.txt")
x=replacek(data,"befire","after")
write_file("a.txt",x)
