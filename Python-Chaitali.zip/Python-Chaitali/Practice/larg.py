lst=[200,300,400,333]
print(max(lst))
print(min(lst))