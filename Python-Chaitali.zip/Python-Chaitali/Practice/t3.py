def find_substring(main_string, substring):
    """Return the starting index of the substring in the main string, or -1 if not found."""
    index = main_string.find(substring)
    return index

def format_full_name(first_name, last_name):
    """Return the full name in the format 'Last, First'."""
    return f"{last_name}, {first_name}"

def even_indexed_chars(input_string):
    """Return a new string consisting of characters at even indices."""
    return input_string[::2]

def reverse_string_slicing(input_string):
    """Return the reversed version of the string using slicing."""
    return input_string[::-1]

def substring_from_end(input_string, n):
    """Return the last n characters of the string."""
    return input_string[-n:] if n <= len(input_string) else input_string

# Main Program
if __name__ == "__main__":
    # Test Assignment 7
    main_string = "Hello, world!"
    substring = "world"
    print(f"Starting index of '{substring}' in '{main_string}': {find_substring(main_string, substring)}")

    # Test Assignment 8
    first_name = "John"
    last_name = "Doe"
    print(f"Formatted full name: {format_full_name(first_name, last_name)}")

    # Test Assignment 9
    test_string = "abcdefg"
    print(f"Even indexed characters in '{test_string}': {even_indexed_chars(test_string)}")

    # Test Assignment 10
    string_to_reverse = "Hello"
    print(f"Reversed string of '{string_to_reverse}': {reverse_string_slicing(string_to_reverse)}")

    # Test Assignment 11
    string_for_substring = "Hello, world!"
    n = 5
    print(f"Last {n} characters of '{string_for_substring}': {substring_from_end(string_for_substring, n)}")
