with open("file2.txt","w")as file:
    file.write("hee1")
with open("file2.txt","r")as file:
    print(file.read())
