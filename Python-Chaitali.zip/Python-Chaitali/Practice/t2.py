import csv

# Initialize the product inventory as an empty dictionary
product_inventory = {}

def add_product(product_inventory, product_id, product_tuple):
    """Add a product to the inventory."""
    product_inventory[product_id] = product_tuple

def update_quantity(product_inventory, product_id, new_quantity):
    """Update the quantity of a specified product."""
    if product_id in product_inventory:
        product_name, price, _ = product_inventory[product_id]  # Unpack the tuple
        product_inventory[product_id] = (product_name, price, new_quantity)  # Update quantity
    else:
        print(f"Product ID {product_id} not found in inventory.")

def display_products(product_inventory):
    """Display all products in the inventory."""
    print(f"{'Product ID':<12} {'Product Name':<20} {'Price':<10} {'Quantity':<10} {'Total Price':<12}")
    print("-" * 70)
    for product_id, (product_name, price, quantity) in product_inventory.items():
        total_price = price * quantity
        print(f"{product_id:<12} {product_name:<20} {price:<10} {quantity:<10} {total_price:<12}")

def save_to_csv(product_inventory, filename):
    """Save the product inventory to a CSV file."""
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['Product ID', 'Product Name', 'Price', 'Quantity', 'Total Price'])
        for product_id, (product_name, price, quantity) in product_inventory.items():
            total_price = price * quantity
            writer.writerow([product_id, product_name, price, quantity, total_price])
    print(f"Inventory saved to {filename}.")

# Main program
if __name__ == "__main__":
    # Sample products to add
    add_product(product_inventory, 1, ("Apple", 0.5, 100))
    add_product(product_inventory, 2, ("Banana", 0.3, 150))
    add_product(product_inventory, 3, ("Orange", 0.4, 200))

    # Display all products
    display_products(product_inventory)

    # Update quantity of a product
    update_quantity(product_inventory, 2, 120)  # Update Banana's quantity
    print("\nUpdated inventory after changing Banana's quantity:")
    display_products(product_inventory)

    # Save inventory to CSV file
    save_to_csv(product_inventory, 'product_inventory.csv')
