def reverse_string(s):
    # Base case: if the string is empty or has one character, return it as is
    if len(s) <= 1:
        return s
    # Recursive case: reverse the rest of the string and add the first character to the end
    else:
        return s[-1] + reverse_string(s[:-1])

# Example usage
input_string = "hello"
reversed_string = reverse_string(input_string)
print(f"The reversed string of '{input_string}' is '{reversed_string}'.")  # Output: 'olleh'
