# Assignment 7: Write a function to work on dictionary
# Given a dictionary of students and their marks
# e.g. : dict ={‘Mayura’:89,’Pravin’:92,’Ketaki’:95,’Chinmay’:99} 

# Tasks:
# Find total number of students in the list 
# Change Pravin’s marks
# Remove ‘Ketaki' and her marks
# Sort students alphabetically and print students and their marks
dict1 ={"Mayura":89,"Pravin":92,"Ketaki":95,"Chinmay":99} 
print(len(dict1))
dict1["Pravin"]=45
print(dict1)
dict1.pop("Ketaki")
print(dict1)
s=dict(sorted(dict1.items()))
print(s)