class Appliance:
    def __init__(self, brand, power_rating):
        self.brand = brand  # Brand of the appliance
        self.power_rating = power_rating  # Power rating in watts

    def energy_usage(self, hours):
        energy_consumed = self.power_rating * hours / 1000  # Convert to kilowatt-hours (kWh)
        print(f"Energy consumed by {self.brand}: {energy_consumed:.2f} kWh")

    def display(self):
        print(f"This is a {self.brand} appliance.")


class WashingMachine(Appliance):
    def __init__(self, brand, power_rating, capacity):
        super().__init__(brand, power_rating)  # Call to the base class constructor
        self.capacity = capacity  # Capacity in kg

    def display(self):
        print(f"This is a {self.brand} washing machine with {self.capacity} kg capacity.")


class Refrigerator(Appliance):
    def __init__(self, brand, power_rating, volume):
        super().__init__(brand, power_rating)  # Call to the base class constructor
        self.volume = volume  # Volume in liters

    def display(self):
        print(f"This is a {self.brand} refrigerator with {self.volume} liters capacity.")


class Microwave(Appliance):
    def __init__(self, brand, power_rating, power_levels):
        super().__init__(brand, power_rating)  # Call to the base class constructor
        self.power_levels = power_levels  # Number of power levels

    def display(self):
        print(f"This is a {self.brand} microwave with {self.power_levels} power levels.")


# Main program
if __name__ == "__main__":
    # Create instances of appliances
    washing_machine = WashingMachine("LG", 2000, 7)  # 2000 watts, 7 kg capacity
    refrigerator = Refrigerator("Samsung", 150, 300)  # 150 watts, 300 liters volume
    microwave = Microwave("Panasonic", 1000, 5)  # 1000 watts, 5 power levels

    # Display information about each appliance
    washing_machine.display()
    refrigerator.display()
    microwave.display()

    # Function to get valid hours input from the user
    def get_hours_input(appliance_name):
        while True:
            try:
                hours = float(input(f"Enter the number of hours {appliance_name} has been used: "))
                if hours < 0:
                    raise ValueError("The number of hours cannot be negative.")
                return hours
            except ValueError as e:
                print(f"Invalid input: {e}. Please enter a valid number.")

    # Get hours from the user and calculate energy usage
    washing_machine_hours = get_hours_input("the washing machine")
    washing_machine.energy_usage(washing_machine_hours)

    refrigerator_hours = get_hours_input("the refrigerator")
    refrigerator.energy_usage(refrigerator_hours)

    microwave_hours = get_hours_input("the microwave")
    microwave.energy_usage(microwave_hours)
