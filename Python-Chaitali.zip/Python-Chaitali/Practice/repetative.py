def rep(s):
    result=" "
    for char in s:
        if char not in result:
            result+=char
    print(result)
            
rep("sssfffdderrr")


