# import re
# import csv
# with open("file.csv","r")as file:
#     data=file.read()
#     print(data)
# with open("file2.csv","w")as file:
#     writer=csv.writer(file)
#     datetime_regex=r"#datetime=(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2}:\d{2})"
#     match=re.search(datetime_regex,data)
#     if match:
#         date=match.group(1)
#         time=match.group(2)
#         new = re.sub(datetime_regex,f"#date={date}#time={time}",data)
#         writer.writerow(new)
import re
import csv

# Regex to extract date and time from datetime component
datetime_regex = r"#datetime=(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2}:\d{2})"

# Read from the input CSV file
def read_csv(filename):
    with open(filename, 'r') as infile:
        return [row[0] for row in csv.reader(infile)]

# Process each record to split datetime
def process_record(record):
    match = re.search(datetime_regex, record)
    if match:
        date = match.group(1)
        time = match.group(2)
        return re.sub(datetime_regex, f"#date={date}#time={time}", record)
    return record

# Write to the output CSV file
def write_csv(filename, records):
    with open(filename, 'w', newline='') as outfile:
        writer = csv.writer(outfile)
        for record in records:
            writer.writerow([record])

# Main function to process the CSV
def process_csv(input_file, output_file):
    records = read_csv(input_file)
    processed_records = [process_record(record) for record in records]
    write_csv(output_file, processed_records)

# Input and output file names
input_file = 'input.csv'
output_file = 'output.csv'

# Run the processing function
process_csv(input_file, output_file)

print(f"Processed {input_file} and saved to {output_file}.")
