def read_file(file_name):
    """Read the contents of a file and return as a list of lines."""
    with open(file_name, "r") as file:
        return file.readlines()

def write_file(file_name, lines):
    """Write the modified lines back to the file."""
    with open(file_name, "w") as file:
        file.writelines(lines)

def replace_keyword(lines, old_keyword, new_keyword):
    """Replace all occurrences of old_keyword with new_keyword in the given lines."""
    return [line.replace(old_keyword, new_keyword) for line in lines]

def main():
    # Specify the file name and the keywords to replace
    file_name = "your_file.txt"  # Change to your actual file name
    old_keyword = "after"
    new_keyword = "before"
    
    # Read the file content
    lines = read_file(file_name)
    
    # Replace the keywords
    modified_lines = replace_keyword(lines, old_keyword, new_keyword)
    
    # Write the modified content back to the file
    write_file(file_name, modified_lines)

    print("Replacement done successfully!")

if __name__ == "__main__":
    main()
