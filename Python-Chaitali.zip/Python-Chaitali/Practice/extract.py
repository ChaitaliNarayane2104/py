import re

def extract_log_details(log_entry):
    # Define the regular expression pattern to match the log entry
    pattern = r'\[(.*?)\] (\w+) \(IP: (\d+\.\d+\.\d+\.\d+)\) - "(.*)"'
    
    # Use re.search to find matches
    match = re.search(pattern, log_entry)
    
    if match:
        # Extract details from the match object
        timestamp = match.group(1)
        username = match.group(2)
        ip_address = match.group(3)
        activity = match.group(4)
        
        # Return the details as a dictionary
        return {
            'timestamp': timestamp,
            'username': username,
            'ip_address': ip_address,
            'activity': activity
        }
    else:
        raise ValueError("Log entry format is incorrect.")

# Sample log entry
log_entry = '[2024-10-10 12:34:56] s_kumar (IP: 192.168.1.1) - "Login successful"'

# Extract log details
try:
    log_details = extract_log_details(log_entry)
    # Print extracted details
    print("Timestamp:", log_details['timestamp'])
    print("Username:", log_details['username'])
    print("IP Address:", log_details['ip_address'])
    print("Activity:", log_details['activity'])
except ValueError as e:
    print(e)
