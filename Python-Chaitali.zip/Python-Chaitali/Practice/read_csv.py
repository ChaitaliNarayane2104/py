import csv
# data = [
#     ['Name', 'Age', 'City'],
#     ['Alice', '30', 'New York'],
#     ['Bob', '25', 'Los Angeles'],
#     ['Chaitali', '35', 'Chicago']
# ]
# with open("file5.csv","w",newline="") as file:
#     writer= csv.writer(file)
#     writer.writerows(data)

# Open or create the CSV file in append mode
with open('students.csv', 'a', newline='') as file:
    writer = csv.writer(file)
    
    # Accept input from the user
    name = input("Enter student's name: ")
    age = input("Enter student's age: ")
    marks = input("Enter student's marks: ")

    # Write the input as a row in the CSV file
    writer.writerow([name, age, marks])

print("Student details have been added to the CSV file.")

