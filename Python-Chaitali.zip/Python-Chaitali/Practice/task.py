def count_words(sentence):
    # Create an empty dictionary to store word frequencies
    word_count = {}
    
    # Split the sentence into words using whitespace
    words = sentence.split()
    
    # Count each word's frequency
    for word in words:
        # Normalize the word to lowercase for case-insensitive counting
        word = word.lower()
        if word in word_count:
            word_count[word] += 1  # Increment count if word exists
        else:
            word_count[word] = 1  # Initialize count if word is new
            
    return word_count

def print_word_frequencies(word_count):
    # Print each word and its corresponding frequency
    for word, frequency in word_count.items():
        print(f"{word}: {frequency}")

# Main program
if __name__ == "__main__":
    # Prompt the user to enter a sentence
    sentence = input("Enter a sentence: ")
    
    # Count the words in the sentence
    word_count = count_words(sentence)
    
    # Print the word frequencies
    print_word_frequencies(word_count)
