def sum_of_digits(n):
    # Base case: when n is a single digit, return n
    if n < 10:
        return n
    # Recursive case: sum the last digit and call the function with the remaining digits
    else:
        return n % 10 + sum_of_digits(n // 10)

# Example usage
number = 12345
result = sum_of_digits(number)
print(f"The sum of the digits of {number} is {result}.")  # Output: The sum of the digits of 12345 is 15.
