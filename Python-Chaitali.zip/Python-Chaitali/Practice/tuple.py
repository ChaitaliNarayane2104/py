# reate a tuple named shopping_cart that contains the following items: 'laptop', 'headphones', 'keyboard', 'mouse'.
# Print the tuple.
# Access and print the first item in the shopping_cart.
# Access and print the last item in the shopping_cart.
# Concatenate the shopping_cart tuple with another tuple ('tablet', 'smartphone') and print the result.
# Unpack the shopping_cart tuple into four variables: item1, item2, item3, item4.
# Print the variables to verify the unpacking.
# Use the .count() method to count how many times 'mouse' appears in the shopping_cart tuple.
# Use the .index() method to find the index of 'keyboard' in the tuple.

tuple1=('laptop','mouse', 'headphones', 'keyboard', 'mouse')
tuple2=('tablet', 'smartphone')
print(tuple1)
print(tuple1[-1])
print(tuple1+tuple2)
a,b,c,d,e=tuple1
print(a)
print(b)
print(c)
print(d)
print(tuple1.count("mouse"))
print(tuple1.index("laptop"))
