# Assignment 2: Masking PII

# Implement a function mask_sensitive_info(info, info_type) that takes two parameters:
# string: The string containing the sensitive information.
# string_type: A string indicating the type of information. It can be "email" or "credit_card".
# Email : Mask the characters in the local part of the email (before the @ symbol) except for the first and last character. 
# “Mayura.kumari@xyz.com" should become “m***i@xyz.com"
# Credit card : Mask all but the last four digits of the credit card number.
# "1234 5678 9101 1121" should become "**** **** **** 1121".

# Exception handling:
# If the info_type is not recognized, raise a ValueError with the message "Invalid info type".
# Handle more exceptions for cases such as incorrect formatting of the input information

# Assignment 2: Masking PII

# Implement a function mask_sensitive_info(info, info_type) that takes two parameters:
# string: The string containing the sensitive information.
# string_type: A string indicating the type of information. It can be "email" or "credit_card".
# Email : Mask the characters in the local part of the email (before the @ symbol) except for the first and last character. 
# “Mayura.kumari@xyz.com" should become “m***i@xyz.com"
# Credit card : Mask all but the last four digits of the credit card number.
# "1234 5678 9101 1121" should become "**** **** **** 1121".

# Exception handling:
# If the info_type is not recognized, raise a ValueError with the message "Invalid info type".
# Handle more exceptions for cases such as incorrect formatting of the input information

# def mask_sensitive_info(info, info_type):
#     if info_type=="email":
#          #print(x[0] + '*' * 3 + x[x.index('@'):])
#         return info[0]+'*'*3 + info[info.index('@'):]
#     elif info_type=="credit":
#         return '*'*(len(info)-4)+info[-4:]
# e=input("enter the email:")
# c=int(input("enter the credit card:"))
# print(mask_sensitive_info(e,'email'))
# print(mask_sensitive_info(c,'credit'))


def mask(info,info_type):
    try:
        if info_type=="email":
            if '@' not in info or info.count("@")!=1:
                raise ValueError("invalid email format")
            return info[0]+"*"*3+info[info.index("@"):]
        elif info_type=="credit":
            if len(info)!=16:
                raise ValueError("invalid credit number")
            return '*'*(len(info)-4)+info[-4:]
    except ValueError as e:
        return str(e)
e=input("enter the email:")
x=input("enter the credit:")
print(mask(e,"email"))
print(mask(x,"credit"))