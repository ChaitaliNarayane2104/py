class URLShortener:
    url_dict = {}  # Class variable to store original URLs and their shortened versions
    base_url = "http://short.url/"  # Base URL for shortened links
    count = 1  # Counter for generating unique shortened URLs

    def add_url(self, original_url):
        # Check if the original URL already exists in the dictionary
        if original_url in self.url_dict:
            print(f"The URL already exists: {self.url_dict[original_url]}")
            return self.url_dict[original_url]
        
        # Generate a unique shortened URL
        shortened_url = self.base_url + str(self.count)
        self.url_dict[original_url] = shortened_url  # Add to dictionary
        print(f"Shortened URL: {shortened_url}")  # Display the shortened URL
        
        # Increment the counter for the next URL
        self.count += 1
        return shortened_url

# Example usage
url_shortener = URLShortener()
url_shortener.add_url("https://www.example.com")  # http://short.url/1
url_shortener.add_url("https://www.python.com")   # http://short.url/2
url_shortener.add_url("https://www.pandas.com")    # http://short.url/3
url_shortener.add_url("https://www.example.com")   # The URL already exists: http://short.url/1
