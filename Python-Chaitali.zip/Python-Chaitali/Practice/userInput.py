# # # import csv
# # # with open("test","w") as file:
# # #     file.write("hello")
# # # with open("test","r") as file:
# # #     print(file.read())

# # import csv
# # data = [
# #     ['name ', 'age', 'grade'],
# #     ['neha ', '24', 'a'],
# #     ['chaitali', '21', 'b'],
# #     ['vaishali', '25', 'c']
# # ]
# # with open("test1","w",newline='') as file:
# #     writer=csv.writer(file)
# #     writer.writerows(data)
# # with open("test1","r") as file:
# #     reader=csv.reader(file)
# #     for row in reader:
# #         print(row)

# # def write(filename,text):
# #     with open(filename,"w") as file:
# #         file.write(text)
# # write("test","hello")
# # def read(filename):
# #     with open(filename,"r") as file:
# #         print(file.read())
# # read("test")

# # Assignment 4: Store dictionary contents to file.

# # Accept student details from user (Name, Roll No, Science, Maths, English marks), store in a dictionary. 
# # Calculate average and add to dictionary. 
# # Open file in append mode. 
# # Add dictionary contents to file.
# import csv
# dict2={}
# dict2["name"]=input("enter the name:")
# dict2["Roll"]=int(input("enter the roll"))
# dict2["sci"]=int(input("enter marks sci"))
# dict2["math"]=int(input("enter marks math"))
# dict2["eng"]=int(input("enter marks eng"))
# dict2.update()

# with open("test","a",newline='') as file:
#     #writer=file.write(str(dict2))
#     writer=csv.DictWriter("test",str(dict2))



import csv
student = {}
student["name"] = input("Enter the name: ")
student["Roll"] = int(input("Enter the roll number: "))
student["sci"] = int(input("Enter marks for Science: "))
student["math"] = int(input("Enter marks for Maths: "))
student["eng"] = int(input("Enter marks for English: "))
average = (student["sci"] + student["math"] + student["eng"]) / 3
student["average"] = round(average, 2)
student.update()
with open("students.csv", "a", newline='') as file:
    writer = csv.DictWriter(file, fieldnames=student)
    writer.writerow(student)
    print(student)

print("Student details added to the file successfully.")
