words = ['apple', 'banana', 'cherry']
# capitalized_words = list(map(lambda word: word.capitalize(), words))
# print(capitalized_words)
# c=list(map(lambda x:x.capitalize(),words))
# print(c)

l=list(map(lambda x:len(x),words))
print(l)