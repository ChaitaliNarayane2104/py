
import csv

dict2={}
ch="y"
while ch=="y":
    dict2["name"]=input("enter the name:")
    dict2["Roll"]=int(input("enter the roll"))
    dict2["sci"]=int(input("enter marks sci"))
    dict2["math"]=int(input("enter marks math"))
    dict2["eng"]=int(input("enter marks eng"))
    dict2.update()
    with open("file14.csv","a") as file:
        writer=csv.writer(file)
        #writer.writerow(str(dict2))
        file.write(str(dict2)+"\n")
    
        ch=input("do you want to cont:")