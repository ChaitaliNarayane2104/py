# Assignment 9: Online Food management System
# FoodItem class:
# Attributes : name (string): Name of the food item.
# price (float): Price of the food item.
# category (string): Category of the food item (e.g., "Starter", "Main Course", "Dessert").
# Method: display_info(): Display food item details including name, price, and category.


class FoodItem:
    def __init__(self,name,price,category):
        self.name=name
        self.price=price
        self.category=category
    def display_info(self):
        print(self.name,self.price,self.category)
obj=FoodItem("chaitali",222222,"A")
obj.display_info()
