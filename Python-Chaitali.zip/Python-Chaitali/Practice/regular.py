# Assignment 10: 
# Read a csv file which has a records in the format : 	#unitid=1#temp=38#datetime=2024-09-21T15:30:00
# Create a regular expression for extracting datetime component  
# Split datetime component into date and time components for each record in each row. 
# Create a new csv file with the format   
# 	#unitid=1#temp=38#date=2024-09-21#time=15:30:00

# Note: Use CSV methods to read and write to CSV file.
import re

# Sample data
data = "#unitid=1#temp=38#datetime=2024-09-21T15:30:00"

# Regular expression to extract the datetime component
datetime_regex = r"#datetime=(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2}:\d{2})"

# Search for the datetime in the string
match = re.search(datetime_regex, data)

if match:
    # Extracted date and time
    date = match.group(1)
    time = match.group(2)
    
    # Replacere the original datetime with the desired format
    formatted_data = re.sub(datetime_regex, f"#date={date}#time={time}", data)
    
    # Display the formatted string
    print(formatted_data)
else:
    print("No datetime found in the string.")
