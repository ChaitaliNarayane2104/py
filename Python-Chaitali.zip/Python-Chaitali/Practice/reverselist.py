# list1=[1,2,3,4]
# x=list1[::-1]
# print(x)

def write_file(lst,filename):
    with open(filename,"w")as file:
        return file.write(str(lst))

def read_file(filename):
    with open(filename)as file:
        print(file.read())
filename="test.txt"
lst=[1,2,3,4]
write_file(lst,filename)
read_file(filename)